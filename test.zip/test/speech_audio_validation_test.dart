import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:edumate/services/speech/speech_service.dart';

void main() {
  group('SpeechService.inspectWavFile', () {
    late Directory directory;

    setUp(() async {
      directory = await Directory.systemTemp.createTemp('edumate_audio_test_');
    });

    tearDown(() async {
      if (await directory.exists()) await directory.delete(recursive: true);
    });

    test('accepts valid mono 16 kHz PCM with usable signal', () async {
      final file = File('${directory.path}/signal.wav');
      await file.writeAsBytes(_wav(signal: true));

      final result = await SpeechService.inspectWavFile(file.path);

      expect(result.fileExists, isTrue);
      expect(result.isValidWav, isTrue);
      expect(result.hasUsableSignal, isTrue);
      expect(result.sampleRate, 16000);
      expect(result.channels, 1);
      expect(result.bitsPerSample, 16);
      expect(result.durationSeconds, 0.5);
      expect(result.rmsAmplitude, greaterThan(0.003));
      expect(result.peakAmplitude, greaterThan(0.015));
    });

    test('rejects valid but silent audio before STT', () async {
      final file = File('${directory.path}/silence.wav');
      await file.writeAsBytes(_wav(signal: false));

      final result = await SpeechService.inspectWavFile(file.path);

      expect(result.isValidWav, isTrue);
      expect(result.hasUsableSignal, isFalse);
      expect(result.error, contains('no usable microphone signal'));
    });

    test('rejects malformed WAV without throwing', () async {
      final file = File('${directory.path}/invalid.wav');
      await file.writeAsBytes(List<int>.filled(60, 0));

      final result = await SpeechService.inspectWavFile(file.path);

      expect(result.fileExists, isTrue);
      expect(result.isValidWav, isFalse);
      expect(result.error, isNotNull);
    });

    test('reports a missing file without throwing', () async {
      final result =
          await SpeechService.inspectWavFile('${directory.path}/missing.wav');

      expect(result.fileExists, isFalse);
      expect(result.isValidWav, isFalse);
    });

    test('rejects an empty recording path with a useful failure', () async {
      final result = await SpeechService.inspectWavFile('');

      expect(result.fileExists, isFalse);
      expect(result.isValidWav, isFalse);
      expect(result.error, 'Recording path is empty.');
    });
  });
}

Uint8List _wav({required bool signal}) {
  const sampleCount = 8000;
  final payloadLength = sampleCount * 2;
  final bytes = Uint8List(44 + payloadLength);
  final data = ByteData.sublistView(bytes);
  void ascii(int offset, String value) {
    for (var i = 0; i < value.length; i++) {
      bytes[offset + i] = value.codeUnitAt(i);
    }
  }

  ascii(0, 'RIFF');
  data.setUint32(4, bytes.length - 8, Endian.little);
  ascii(8, 'WAVE');
  ascii(12, 'fmt ');
  data.setUint32(16, 16, Endian.little);
  data.setUint16(20, 1, Endian.little);
  data.setUint16(22, 1, Endian.little);
  data.setUint32(24, 16000, Endian.little);
  data.setUint32(28, 32000, Endian.little);
  data.setUint16(32, 2, Endian.little);
  data.setUint16(34, 16, Endian.little);
  ascii(36, 'data');
  data.setUint32(40, payloadLength, Endian.little);
  if (signal) {
    for (var i = 0; i < sampleCount; i++) {
      data.setInt16(44 + i * 2, i.isEven ? 12000 : -12000, Endian.little);
    }
  }
  return bytes;
}
