import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:edumate/app/app.dart';
import 'package:edumate/features/settings/settings_screen.dart';
import 'package:edumate/features/benchmark/benchmark_screen.dart';

void main() {
  testWidgets('Edumate app loads', (WidgetTester tester) async {
    await tester.pumpWidget(const EdumateApp());

    expect(find.text('Edumate'), findsOneWidget);
    expect(find.text('Namaste! 👋'), findsOneWidget);
  });

  testWidgets('Home Learning card opens lessons and lesson flow works', (WidgetTester tester) async {
    await tester.pumpWidget(const EdumateApp());

    await tester.ensureVisible(find.text('Learning'));
    await tester.tap(find.text('Learning'));
    await tester.pumpAndSettle();
    expect(find.text('Choose a lesson'), findsOneWidget);
    expect(find.text('Basic Greetings'), findsOneWidget);

    final lessonCard = find.ancestor(
      of: find.text('Basic Greetings'),
      matching: find.byType(Card),
    );
    final startLesson = find.descendant(of: lessonCard, matching: find.text('Start Lesson'));
    await tester.ensureVisible(startLesson);
    await tester.pumpAndSettle();
    await tester.tap(startLesson);
    await tester.pumpAndSettle();
    expect(find.text('Item 1 of 3'), findsOneWidget);

    await tester.tap(find.text('Next'));
    await tester.pumpAndSettle();
    expect(find.text('Item 2 of 3'), findsOneWidget);
    await tester.tap(find.text('Previous'));
    await tester.pumpAndSettle();
    expect(find.text('Item 1 of 3'), findsOneWidget);

    await tester.tap(find.text('Next'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Next'));
    await tester.pumpAndSettle();
    expect(find.text('Item 3 of 3'), findsOneWidget);
    await tester.tap(find.text('Complete'));
    await tester.pumpAndSettle();
    expect(find.text('Lesson Complete 🎉'), findsOneWidget);

    await tester.tap(find.text('Restart Lesson'));
    await tester.pumpAndSettle();
    expect(find.text('Item 1 of 3'), findsOneWidget);
  });

  testWidgets('Settings screen shows offline status and supported language settings', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(360, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const MaterialApp(home: SettingsScreen()));
    await tester.pumpAndSettle();

    expect(find.text('Settings'), findsOneWidget);
    expect(find.text('Offline Mode'), findsOneWidget);
    expect(find.text('Hindi → Mundari'), findsOneWidget);
    expect(find.text('Hindi → Santhali'), findsOneWidget);
    await tester.scrollUntilVisible(
      find.text('Student Mode'),
      250,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    expect(find.text('Student Mode'), findsOneWidget);
    expect(find.text('Teacher Mode'), findsOneWidget);
    await tester.scrollUntilVisible(
      find.text('Prototype Status'),
      350,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    expect(find.text('Prototype Status'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Benchmark measures local lookups on a narrow phone screen', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(360, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const MaterialApp(home: BenchmarkScreen()));
    await tester.pumpAndSettle();

    expect(find.text('Performance Benchmark'), findsOneWidget);
    expect(find.text('OFFLINE BENCHMARK'), findsOneWidget);
    expect(find.text('Not run yet'), findsOneWidget);
    expect(find.text('Not tested'), findsWidgets);

    final runButton = find.text('Run Benchmark');
    await tester.ensureVisible(runButton);
    await tester.pumpAndSettle();
    await tester.tap(runButton);
    await tester.pump();
    await tester.runAsync(() => Future<void>.delayed(const Duration(seconds: 1)));
    for (var i = 0; i < 100 && find.text('Running benchmark…').evaluate().isNotEmpty; i++) {
      await tester.pump(const Duration(milliseconds: 50));
    }
    expect(find.text('Running benchmark…'), findsNothing);
    await tester.pump();

    expect(find.text('First lookup'), findsOneWidget);
    expect(find.text('Warm lookup'), findsOneWidget);
    expect(find.text('Reverse lookup'), findsOneWidget);
    expect(find.text('इनकु कमजोरोःतानाको'), findsOneWidget);
    expect(find.text('वे भी कमजोर पड़ रहे हैं'), findsWidgets);
    expect(tester.takeException(), isNull);
  });
}
