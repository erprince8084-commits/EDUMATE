import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:edumate/features/voice_translation/voice_translation_screen.dart';
import 'package:edumate/services/speech/offline_pipeline_test_runner.dart';
import 'package:edumate/services/speech/speech_service.dart';
import 'package:edumate/services/speech/voice_pipeline_state.dart';
import 'package:edumate/services/translation/translation_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('TranslationService voice lookups', () {
    late TranslationService service;

    setUp(() {
      service = TranslationService();
    });

    test('returns the exact bundled Hindi to Mundari sentence', () async {
      final translation =
          await service.translateHindiToMundari('वे भी कमजोर पड़ रहे हैं');

      expect(translation, 'इनकु कमजोरोःतानाको');
      expect(service.isLoaded, isTrue);
    });

    test('does not invent a result for an unknown Hindi sentence', () async {
      final translation = await service.translateHindiToMundari(
        'यह वाक्य ऑफलाइन डेटा में मौजूद नहीं है।',
      );

      expect(translation, isNull);
    });
  });

  test('allows the successful pipeline transitions in order', () {
    final machine = VoicePipelineStateMachine();

    machine.transitionTo(VoicePipelinePhase.requestingPermission);
    machine.transitionTo(VoicePipelinePhase.recording);
    machine.transitionTo(VoicePipelinePhase.validatingAudio);
    machine.transitionTo(VoicePipelinePhase.speechToText);
    machine.transitionTo(VoicePipelinePhase.translation);
    machine.transitionTo(VoicePipelinePhase.textToSpeech);
    machine.transitionTo(VoicePipelinePhase.completed);

    expect(machine.phase, VoicePipelinePhase.completed);
  });

  test('rejects skipping audio validation before STT', () {
    final machine = VoicePipelineStateMachine();
    machine.transitionTo(VoicePipelinePhase.requestingPermission);
    machine.transitionTo(VoicePipelinePhase.recording);

    expect(
      () => machine.transitionTo(VoicePipelinePhase.speechToText),
      throwsStateError,
    );
  });

  test('can retry after silent audio without changing the prior result', () {
    final machine = VoicePipelineStateMachine();
    machine.transitionTo(VoicePipelinePhase.requestingPermission);
    machine.transitionTo(VoicePipelinePhase.recording);
    machine.transitionTo(VoicePipelinePhase.validatingAudio);
    machine.transitionTo(VoicePipelinePhase.silentAudio);
    machine.transitionTo(VoicePipelinePhase.requestingPermission);

    expect(machine.phase, VoicePipelinePhase.requestingPermission);
  });

  group('Offline pipeline test runner', () {
    late Directory directory;

    setUp(() async {
      directory = await Directory.systemTemp.createTemp('edumate_pipeline_');
    });

    tearDown(() async {
      if (await directory.exists()) await directory.delete(recursive: true);
    });

    test('missing sample returns a clear failure and bypasses microphone',
        () async {
      final machine = VoicePipelineStateMachine();
      final runner = _runner(
        machine: machine,
        directory: directory,
        assets: const [],
      );

      final result = await runner.run();

      expect(result.error, contains('No bundled Hindi speech sample'));
      expect(result.microphoneBypassed, isTrue);
      expect(machine.phase, VoicePipelinePhase.sampleUnavailable);
      expect(result.sttStatus, VoiceStepStatus.notStarted);
    });

    test('silent sample fails validation without calling STT', () async {
      var recognitionCalls = 0;
      final runner = _runner(
        machine: VoicePipelineStateMachine(),
        directory: directory,
        assets: const ['assets/audio/hindi_silent.wav'],
        bytes: _wav(signal: false),
        onRecognize: (_) async {
          recognitionCalls++;
          return null;
        },
      );

      final result = await runner.run();

      expect(result.audio?.isValidWav, isTrue);
      expect(result.audio?.hasUsableSignal, isFalse);
      expect(result.sttStatus, VoiceStepStatus.notStarted);
      expect(recognitionCalls, 0);
    });

    test('invalid sample fails validation without calling STT', () async {
      var recognitionCalls = 0;
      final runner = _runner(
        machine: VoicePipelineStateMachine(),
        directory: directory,
        assets: const ['assets/audio/hindi_invalid.wav'],
        bytes: Uint8List(60),
        onRecognize: (_) async {
          recognitionCalls++;
          return null;
        },
      );

      final result = await runner.run();

      expect(result.audio?.isValidWav, isFalse);
      expect(result.sttStatus, VoiceStepStatus.notStarted);
      expect(recognitionCalls, 0);
    });

    test('valid sample is passed to recognizer; no recognition is fabricated',
        () async {
      var recognitionCalls = 0;
      final machine = VoicePipelineStateMachine();
      final runner = _runner(
        machine: machine,
        directory: directory,
        assets: const ['assets/audio/hindi_test_fixture.wav'],
        bytes: _wav(signal: true),
        onRecognize: (_) async {
          recognitionCalls++;
          throw StateError('Recognizer not executed in this unit test.');
        },
      );

      final result = await runner.run();

      expect(result.audio?.hasUsableSignal, isTrue);
      expect(recognitionCalls, 1);
      expect(result.sttStatus, VoiceStepStatus.error);
      expect(result.recognizedText, isNull);
      expect(machine.phase, VoicePipelinePhase.sttFailed);
      expect(result.microphoneBypassed, isTrue);
    });
  });

  testWidgets('test mode reports missing sample without requesting microphone',
      (tester) async {
    var permissionMethodCalls = 0;
    const permissionChannel =
        MethodChannel('flutter.baseflow.com/permissions/methods');
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(permissionChannel, (call) async {
      permissionMethodCalls++;
      return 0;
    });

    await tester.binding.setSurfaceSize(const Size(420, 1200));
    await tester.pumpWidget(
      const MaterialApp(home: VoiceTranslationScreen()),
    );
    await tester.pumpAndSettle();
    final button = find.text('Run Offline Pipeline Test');
    await tester.scrollUntilVisible(
      button,
      400,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    await tester.tap(button);
    await tester.pumpAndSettle();

    expect(permissionMethodCalls, 0);
    expect(find.text('TEST MODE — MICROPHONE BYPASSED'), findsOneWidget);
    expect(
        find.textContaining('No bundled Hindi speech sample'), findsOneWidget);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.binding.setSurfaceSize(null);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(permissionChannel, null);
  });
}

OfflinePipelineTestRunner _runner({
  required VoicePipelineStateMachine machine,
  required Directory directory,
  required List<String> assets,
  Uint8List? bytes,
  Future<String?> Function(String path)? onRecognize,
}) {
  return OfflinePipelineTestRunner(
    stateMachine: machine,
    listSampleAssets: () async => assets,
    materializeSample: (asset) async {
      final file = File('${directory.path}/${asset.split('/').last}');
      await file.writeAsBytes(bytes ?? _wav(signal: true));
      return file.path;
    },
    inspectAudio: SpeechService.inspectWavFile,
    recognizeAudio: onRecognize ?? (_) async => null,
    translateHindi: (_) async => null,
    hasOfflineMundariVoice: () async => false,
    speakMundari: (_) async {},
  );
}

Uint8List _wav({required bool signal}) {
  const samples = 8000;
  final payloadSize = samples * 2;
  final bytes = Uint8List(44 + payloadSize);
  final data = ByteData.sublistView(bytes);
  void ascii(int offset, String text) {
    for (var i = 0; i < text.length; i++) {
      bytes[offset + i] = text.codeUnitAt(i);
    }
  }

  ascii(0, 'RIFF');
  data.setUint32(4, bytes.length - 8, Endian.little);
  ascii(8, 'WAVE');
  ascii(12, 'fmt ');
  data.setUint32(16, 16, Endian.little);
  data.setUint16(20, 1, Endian.little);
  data.setUint16(22, 1, Endian.little);
  data.setUint32(24, 16000, Endian.little);
  data.setUint32(28, 32000, Endian.little);
  data.setUint16(32, 2, Endian.little);
  data.setUint16(34, 16, Endian.little);
  ascii(36, 'data');
  data.setUint32(40, payloadSize, Endian.little);
  if (signal) {
    for (var i = 0; i < samples; i++) {
      data.setInt16(44 + i * 2, i.isEven ? 12000 : -12000, Endian.little);
    }
  }
  return bytes;
}
