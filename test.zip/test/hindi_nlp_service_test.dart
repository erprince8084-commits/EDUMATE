import 'package:flutter_test/flutter_test.dart';

import 'package:edumate/services/translation/hindi_nlp_service.dart';
import 'package:edumate/services/translation/translation_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('HindiNlpService', () {
    late TranslationService translationService;
    late HindiNlpService nlpService;

    setUp(() {
      translationService = TranslationService();
      nlpService = HindiNlpService(translationService: translationService);
    });

    test('keeps exact known dataset match as the highest-priority path',
        () async {
      final result =
          await nlpService.translateHindiToMundari('वे भी कमजोर पड़ रहे हैं');

      expect(result.translatedText, 'इनकु कमजोरोःतानाको');
      expect(result.matchType, NlpMatchType.exact);
      expect(result.score, 1);
      expect(result.isConfident, isTrue);
      expect(nlpService.indexBuildCount, 0);
    });

    test('normalizes sentence-final Hindi punctuation safely', () async {
      final result =
          await nlpService.translateHindiToMundari('वे भी कमजोर पड़ रहे हैं।');

      expect(result.translatedText, 'इनकु कमजोरोःतानाको');
      expect(result.matchType, NlpMatchType.normalizedExact);
      expect(result.sourceText, 'वे भी कमजोर पड़ रहे हैं।');
    });

    test('normalizes internal extra whitespace and tokenizes simply', () async {
      final analysis = nlpService.analyze('  वे   भी कमजोर पड़ रहे हैं  ');
      final result = await nlpService.translateHindiToMundari(
        'वे   भी कमजोर पड़ रहे हैं',
      );

      expect(analysis.normalizedText, 'वे भी कमजोर पड़ रहे हैं');
      expect(analysis.tokens, ['वे', 'भी', 'कमजोर', 'पड़', 'रहे', 'हैं']);
      expect(result.translatedText, 'इनकु कमजोरोःतानाको');
      expect(result.matchType, NlpMatchType.normalizedExact);
    });

    test('does not produce a translation for an unknown sentence', () async {
      final result = await nlpService.translateHindiToMundari(
        'क्वांटम झरना बैंगनी पत्थर',
      );

      expect(result.translatedText, isNull);
      expect(result.matchType, NlpMatchType.none);
      expect(result.isConfident, isFalse);
    });

    test('builds and reuses the normalized index after exact lookup misses',
        () async {
      await nlpService.translateHindiToMundari('वे भी कमजोर पड़ रहे हैं।');
      await nlpService.translateHindiToMundari('वे   भी कमजोर पड़ रहे हैं');

      expect(translationService.isLoaded, isTrue);
      expect(nlpService.isIndexLoaded, isTrue);
      expect(nlpService.indexBuildCount, 1);
    });

    test('retains the original exact TranslationService API', () async {
      final result = await translationService
          .translateHindiToMundari('वे भी कमजोर पड़ रहे हैं');

      expect(result, 'इनकु कमजोरोःतानाको');
    });

    test('can retrieve a high-confidence match from the bundled dataset',
        () async {
      final result = await nlpService.translateHindiToMundari(
        'वे भी बहुत कमजोर पड़ रहे हैं',
      );

      expect(result.translatedText, isNotNull);
      expect(result.matchedHindi, 'वे भी कमजोर पड़ रहे हैं');
      expect(result.matchType, NlpMatchType.similarity);
      expect(result.isConfident, isTrue);
    });
  });

  test('accepts only a high-confidence unique similarity candidate', () async {
    final service = HindiNlpService(
      translationService: _TestTranslationService([
        MapEntry('वे भी कमजोर पड़ रहे हैं', 'जोहार ओड़ा'),
      ]),
    );

    final result =
        await service.translateHindiToMundari('वे भी बहुत कमजोर पड़ रहे हैं');

    expect(result.translatedText, 'जोहार ओड़ा');
    expect(result.matchType, NlpMatchType.similarity);
    expect(result.score, closeTo(6 / 7, 0.0001));
    expect(result.isConfident, isTrue);
  });

  test('returns no translation for a low-confidence candidate', () async {
    final service = HindiNlpService(
      translationService: _TestTranslationService([
        MapEntry('वे कमजोर पड़ रहे हैं', 'जोहार ओड़ा'),
      ]),
    );

    final result =
        await service.translateHindiToMundari('वे भी बहुत कमजोर पड़ रहे हैं');

    expect(result.translatedText, isNull);
    expect(result.matchType, NlpMatchType.none);
    expect(result.isConfident, isFalse);
    expect(result.score, lessThan(HindiNlpService.autoAcceptThreshold));
  });

  test('does not choose between equally similar dataset candidates', () async {
    final service = HindiNlpService(
      translationService: _TestTranslationService([
        MapEntry('वे भी कमजोर पड़ रहे हैं', 'जोहार ओड़ा'),
        MapEntry('वे बहुत कमजोर पड़ रहे हैं', 'सिंगि सितुम'),
      ]),
    );

    final result =
        await service.translateHindiToMundari('वे भी बहुत कमजोर पड़ रहे हैं');

    expect(result.translatedText, isNull);
    expect(result.matchType, NlpMatchType.ambiguous);
    expect(result.isAmbiguous, isTrue);
  });

  test(
      'treats normalized duplicate Hindi rows with different translations as ambiguous',
      () async {
    final service = HindiNlpService(
      translationService: _TestTranslationService([
        MapEntry('वे भी कमजोर पड़ रहे हैं', 'जोहार ओड़ा'),
        MapEntry('वे भी कमजोर पड़ रहे हैं।', 'सिंगि सितुम'),
      ]),
    );

    final result =
        await service.translateHindiToMundari('वे भी कमजोर पड़ रहे हैं!');

    expect(result.translatedText, isNull);
    expect(result.matchType, NlpMatchType.ambiguous);
    expect(result.isAmbiguous, isTrue);
  });
}

class _TestTranslationService extends TranslationService {
  _TestTranslationService(this.rows);

  final List<MapEntry<String, String>> rows;

  @override
  Future<String?> translateHindiToMundari(String text) async {
    final source = text.trim();
    for (final row in rows) {
      if (row.key == source) return row.value;
    }
    return null;
  }

  @override
  Future<List<MapEntry<String, String>>> getHindiToMundariEntries() async =>
      rows;
}
