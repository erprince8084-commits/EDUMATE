# Offline Hindi NLP Retrieval Layer

Edumate's Hindi to Mundari path now adds conservative text normalization and dataset retrieval above the existing `TranslationService`.

## Architecture

Hindi input  
↓  
Conservative Unicode/punctuation/whitespace normalization  
↓  
Existing exact dataset lookup  
↓ (only if exact lookup misses)  
Normalized exact lookup  
↓ (only if that misses)  
Tokenization and inverted-index candidate retrieval  
↓  
Token-set Jaccard similarity  
↓  
Confidence threshold and ambiguity check  
↓  
Return the Mundari text paired with the matched Hindi entry in the bundled dataset

This is an offline retrieval/NLP matching layer, not a generative translation model. It does not create or infer new Mundari text. Existing exact Hindi↔Mundari methods remain available and unchanged; Mundari→Hindi remains exact lookup.

## Matching policy

- Exact `TranslationService` lookup is always tried first and returns score `1.0`.
- Normalization trims/collapses whitespace, ignores punctuation, lowercases where relevant, and unifies common precomposed/decomposed Devanagari nukta forms. It does not stem words or remove stopwords.
- A normalized exact match returns only a dataset pair. Conflicting translations for the same normalized Hindi sentence are marked ambiguous.
- Similarity uses token-set Jaccard: intersection divided by union. Dataset rows are loaded through the existing service, then normalized and indexed lazily once in memory. An inverted token index narrows candidates.
- Automatic retrieval requires score `>= 0.85` (`HindiNlpService.autoAcceptThreshold`) and a lead of at least `0.05` over the next candidate (`minimumScoreMargin`). Otherwise no translation is returned or the result is marked ambiguous.
- At most 50 top-scoring candidates are retained for confidence/ambiguity evaluation. The reported score is a matching score, not translation accuracy.

## Offline behavior and limitations

All data comes from the app-bundled `assets/translation/translation-hi-unr.tsv`; no network, API, embedding model, stemming, or semantic understanding is used. Similar-looking token sets can have different meanings, so the threshold is intentionally conservative and a high score is not proof of linguistic correctness. Native-speaker review remains important, especially for low-resource language content.

The index uses memory proportional to the bundled Hindi dataset and is built lazily on the first normalized/similarity fallback. The existing exact path does not build this index. Subsequent NLP retrieval requests reuse it.

## Future possibilities (not implemented)

- Hindi semantic embeddings or multilingual sentence encoders
- Indic NLP resources
- A dedicated Hindi→Mundari neural translation model
- Low-resource language model training
- Native-speaker validation and evaluation
