# Edumate Voice Pipeline

## Architecture

```text
Microphone
    ↓
WAV recording (mono, 16 kHz, PCM 16-bit)
    ↓
Audio validation (RIFF/WAV, format, duration, RMS, peak)
    ↓
Offline Hindi STT (bundled Sherpa-ONNX model and tokens)
    ↓
Recognized Hindi text
    ↓
Offline exact Hindi → Mundari dataset lookup
    ↓
Mundari text
    ↓
Device Mundari TTS (only an installed, non-network `unr` voice)
    ↓
Audio output
```

## Currently implemented

- Hindi Sherpa-ONNX recognizer initialization is cached and reused; each recording creates and releases its own recognition stream.
- Local microphone capture writes WAV audio into the app's temporary directory.
- WAV validation checks the file, RIFF/WAVE structure, PCM format, mono channel, 16-bit samples, 16 kHz sample rate, duration, RMS, and peak amplitude. Audio without a usable signal is stopped before STT.
- Recognized text is passed to the existing offline `TranslationService`, which performs exact dataset lookup. Unmatched input does not produce guessed Mundari text.
- TTS capability detection accepts only an installed, non-network Mundari (`unr`) voice. It never falls back to Hindi or English.
- The screen reports recording duration, audio validation, STT, translation, TTS call/playback, and total processing timings when those stages run.
- Pipeline states and errors are surfaced in the screen and local diagnostics.
- No cloud speech, translation, or TTS service is used by this pipeline.

## Not yet validated

- Physical Android microphone capture and signal quality.
- Hindi ASR accuracy on a real device and real spoken Hindi.
- Mundari TTS playback on a device with an installed offline `unr` voice.
- Complete end-to-end latency under 3 seconds.
- Performance on low-end Android hardware.

The Android emulator previously produced a correctly formatted WAV with zero RMS and zero peak. The voice screen must therefore report silent input and skip STT for that recording. A physical-device test is still required. No SIH requirement or target latency is claimed as satisfied by this prototype.

## Offline Pipeline Test Mode

Test Mode exists to exercise the processing pipeline without depending on the currently silent emulator microphone. It bypasses microphone recording and microphone permission completely; it does not prove microphone capture works.

```text
TEST MODE
Bundled Hindi WAV
    ↓
Audio Validation
    ↓
Offline Hindi STT
    ↓
Hindi Text
    ↓
Hindi → Mundari Dataset Lookup
    ↓
Mundari Text
    ↓
Mundari TTS (only if an installed offline `unr` voice is available)

REAL MODE
Microphone
    ↓
WAV Recording
    ↓
Audio Validation
    ↓
Offline Hindi STT
    ↓
Hindi Text
    ↓
Hindi → Mundari Dataset Lookup
    ↓
Mundari TTS (only if an installed offline `unr` voice is available)
```

The runner reuses `SpeechService`, `TranslationService`, and `TtsService`. It never requests microphone permission and never supplies a transcription itself. A bundled WAV must pass the same audio validation before the real Sherpa-ONNX recognizer is called. Translation remains exact dataset lookup. TTS is attempted only after capability detection confirms an installed, non-network Mundari voice.

No suitable Hindi WAV sample was present in `assets/audio/` or the repository when Test Mode was added. The UI reports this clearly and instructs adding a real Hindi WAV to `assets/audio/`; no sample or generated speech was added. The existing `assets/audio/` directory is already declared in `pubspec.yaml`.

Test Mode does not validate microphone capture. Physical Android microphone input, real-device Hindi STT accuracy, Mundari TTS playback, low-end Android performance, and end-to-end latency under 3 seconds still require testing on target hardware. No SIH requirement is claimed as satisfied.

## Device test checklist

1. Use a physical Android device and grant microphone permission when prompted.
2. Speak a Hindi sentence in a quiet environment and stop the recording.
3. Confirm WAV validation reports a non-zero RMS and peak before expecting STT.
4. Check actual recognized Hindi and exact dataset lookup output.
5. Confirm Mundari TTS availability separately; text translation remains usable when TTS is unavailable.
6. Record timings on the target hardware before assessing latency goals.
