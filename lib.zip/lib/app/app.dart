import 'package:flutter/material.dart';

import 'theme/app_theme.dart';
import '../features/home/home_screen.dart';

class EdumateApp extends StatelessWidget {
  const EdumateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Edumate',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const HomeScreen(),
    );
  }
}
