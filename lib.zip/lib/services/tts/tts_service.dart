import 'dart:io';

import 'package:flutter_tts/flutter_tts.dart';

/// Device TTS support is accepted only for an installed, non-network Mundari
/// voice. No language fallback is attempted.
class TtsService {
  final FlutterTts _tts = FlutterTts();
  Map<String, dynamic>? _offlineMundariVoice;

  Future<bool> isOfflineMundariAvailable() async =>
      await _findOfflineMundariVoice() != null;

  Future<Map<String, dynamic>?> _findOfflineMundariVoice() async {
    if (!Platform.isAndroid) return null;
    if (_offlineMundariVoice != null) return _offlineMundariVoice;

    final voices = await _tts.getVoices;
    if (voices is! List) return null;

    for (final candidate in voices) {
      if (candidate is! Map) continue;
      final voice = Map<String, dynamic>.from(candidate);
      final locale = (voice['locale'] ?? '').toString();
      final languageCode =
          locale.replaceAll('_', '-').split('-').first.toLowerCase();
      if (languageCode != 'unr') continue;

      final networkRequired = voice['network_required'];
      final networkFlag = networkRequired.toString().toLowerCase();
      final isNetworkVoice = networkRequired == true ||
          networkFlag == '1' ||
          networkFlag == 'true';
      if (isNetworkVoice) continue;

      final installed = await _tts.areLanguagesInstalled([locale]);
      final isInstalled = installed is Map &&
          (installed[locale] == true ||
              installed[locale.toLowerCase()] == true);
      if (!isInstalled) continue;

      _offlineMundariVoice = voice;
      return voice;
    }
    return null;
  }

  /// Speaks using a verified local ISO 639-3 Mundari (`unr`) voice only.
  /// Returns the measured speech playback duration or throws if unavailable.
  Future<Duration> speakMundari(String text) async {
    final value = text.trim();
    if (value.isEmpty) {
      throw ArgumentError.value(text, 'text', 'Text cannot be empty.');
    }

    final voice = await _findOfflineMundariVoice();
    if (voice == null) {
      throw StateError(
          "Mundari voice output is not available on this device's current TTS engine.");
    }

    final locale = voice['locale'].toString();
    await _tts
        .setVoice(voice.map((key, value) => MapEntry(key, value.toString())));
    await _tts.setLanguage(locale);
    await _tts.awaitSpeakCompletion(true);

    final stopwatch = Stopwatch()..start();
    final result = await _tts.speak(value);
    stopwatch.stop();
    if (result != 1) {
      throw StateError(
          'The local Mundari TTS engine could not start playback.');
    }
    return stopwatch.elapsed;
  }

  Future<void> stop() async {
    await _tts.stop();
  }
}
