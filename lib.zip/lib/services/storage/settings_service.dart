import 'storage_service.dart';

/// Stores user-selectable Edumate preferences in the app's local SQLite DB.
class SettingsService {
  SettingsService({StorageService? storage}) : _storage = storage ?? StorageService.instance;

  final StorageService _storage;

  static const defaultLearningMode = 'student';
  static const defaultTranslationPair = 'hindi_mundari';
  static const _learningModeKey = 'learning_mode';
  static const _translationPairKey = 'translation_pair';

  Future<String> getLearningMode() async {
    final saved = await _storage.getPreference(_learningModeKey);
    return saved == 'student' || saved == 'teacher' ? saved! : defaultLearningMode;
  }

  Future<void> saveLearningMode(String mode) async {
    if (mode != 'student' && mode != 'teacher') return;
    await _storage.setPreference(_learningModeKey, mode);
  }

  Future<String> getTranslationPair() async {
    final saved = await _storage.getPreference(_translationPairKey);
    return saved == 'hindi_mundari' || saved == 'mundari_hindi'
        ? saved!
        : defaultTranslationPair;
  }

  Future<void> saveTranslationPair(String pair) async {
    if (pair != 'hindi_mundari' && pair != 'mundari_hindi') return;
    await _storage.setPreference(_translationPairKey, pair);
  }

  /// Restores preference defaults without clearing activity history.
  Future<void> resetSettings() => _storage.clearPreferences();
}
