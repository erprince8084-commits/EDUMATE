import 'package:path/path.dart' as path;
import 'package:sqflite/sqflite.dart';

/// One local SQLite history store shared by the app's offline features.
class StorageService {
  StorageService._();

  static final StorageService instance = StorageService._();
  static const _databaseName = 'edumate_history.db';
  static const _tableName = 'activity_history';
  static const _preferencesTableName = 'app_preferences';
  static Database? _database;
  static Future<Database>? _opening;

  Future<Database> get _db async {
    if (_database != null) return _database!;
    final opening = _opening ??= _openDatabase();
    try {
      return await opening;
    } catch (_) {
      _opening = null;
      rethrow;
    }
  }

  Future<Database> _openDatabase() async {
    final databasePath = path.join(await getDatabasesPath(), _databaseName);
    final database = await openDatabase(
      databasePath,
      version: 2,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE $_tableName (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            sourceText TEXT,
            resultText TEXT,
            createdAt TEXT NOT NULL,
            metadata TEXT
          )
        ''');
        await db.execute('CREATE INDEX history_created_at ON $_tableName(createdAt)');
        await db.execute('''
          CREATE TABLE $_preferencesTableName (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('''
            CREATE TABLE $_preferencesTableName (
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL
            )
          ''');
        }
      },
    );
    _database = database;
    return database;
  }

  /// Adds one activity without retaining files or other large payloads.
  Future<int> addHistory({
    required String type,
    required String title,
    String? sourceText,
    String? resultText,
    String? metadata,
    DateTime? createdAt,
  }) async {
    final database = await _db;
    return database.insert(_tableName, {
      'type': type,
      'title': title,
      'sourceText': sourceText,
      'resultText': resultText,
      'createdAt': (createdAt ?? DateTime.now()).toIso8601String(),
      'metadata': metadata,
    });
  }

  Future<List<HistoryItem>> getHistory({String? type}) async {
    final database = await _db;
    final rows = await database.query(
      _tableName,
      where: type == null ? null : 'type = ?',
      whereArgs: type == null ? null : [type],
      orderBy: 'createdAt DESC, id DESC',
    );
    return rows.map(HistoryItem.fromMap).toList(growable: false);
  }

  Future<void> clearHistory() async {
    final database = await _db;
    await database.delete(_tableName);
  }

  Future<String?> getPreference(String key) async {
    final database = await _db;
    final rows = await database.query(
      _preferencesTableName,
      columns: ['value'],
      where: 'key = ?',
      whereArgs: [key],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  Future<void> setPreference(String key, String value) async {
    final database = await _db;
    await database.insert(
      _preferencesTableName,
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Clears preferences only; local activity history is retained.
  Future<void> clearPreferences() async {
    final database = await _db;
    await database.delete(_preferencesTableName);
  }
}

class HistoryItem {
  const HistoryItem({
    required this.id,
    required this.type,
    required this.title,
    required this.createdAt,
    this.sourceText,
    this.resultText,
    this.metadata,
  });

  final int id;
  final String type;
  final String title;
  final DateTime createdAt;
  final String? sourceText;
  final String? resultText;
  final String? metadata;

  factory HistoryItem.fromMap(Map<String, Object?> row) => HistoryItem(
        id: row['id'] as int,
        type: row['type'] as String,
        title: row['title'] as String,
        sourceText: row['sourceText'] as String?,
        resultText: row['resultText'] as String?,
        createdAt: DateTime.parse(row['createdAt'] as String),
        metadata: row['metadata'] as String?,
      );
}
