import 'package:flutter/services.dart';

class TranslationService {
  final Map<String, String> _hindiToMundari = {};
  final Map<String, String> _mundariToHindi = {};

  bool _isLoaded = false;

  /// Load Hindi ↔ Mundari translation dataset.
  Future<void> loadDataset() async {
    if (_isLoaded) return;

    final data = await rootBundle.loadString(
      'assets/translation/translation-hi-unr.tsv',
    );

    final lines = data.split('\n');

    for (final line in lines) {
      final trimmedLine = line.trim();

      if (trimmedLine.isEmpty) {
        continue;
      }

      final parts = trimmedLine.split('\t');

      if (parts.length < 2) {
        continue;
      }

      final hindi = parts[0].trim();
      final mundari = parts[1].trim();

      if (hindi.isEmpty || mundari.isEmpty) {
        continue;
      }

      _hindiToMundari[hindi] = mundari;
      _mundariToHindi[mundari] = hindi;
    }

    _isLoaded = true;
  }

  /// Hindi → Mundari
  Future<String?> translateHindiToMundari(String text) async {
    await loadDataset();

    final input = text.trim();

    if (input.isEmpty) {
      return null;
    }

    return _hindiToMundari[input];
  }

  /// Mundari → Hindi
  Future<String?> translateMundariToHindi(String text) async {
    await loadDataset();

    final input = text.trim();

    if (input.isEmpty) {
      return null;
    }

    return _mundariToHindi[input];
  }

  /// Number of Hindi → Mundari entries.
  int get hindiToMundariCount => _hindiToMundari.length;

  /// Number of Mundari → Hindi entries.
  int get mundariToHindiCount => _mundariToHindi.length;

  bool get isLoaded => _isLoaded;

  /// Read-only Hindi → Mundari rows for offline retrieval indexes.
  /// Existing exact translation methods and their behavior remain unchanged.
  Future<List<MapEntry<String, String>>> getHindiToMundariEntries() async {
    await loadDataset();
    return List<MapEntry<String, String>>.unmodifiable(
      _hindiToMundari.entries.map(
        (entry) => MapEntry(entry.key, entry.value),
      ),
    );
  }
}
