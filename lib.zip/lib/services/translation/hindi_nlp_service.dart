import 'package:flutter/foundation.dart';

import 'translation_service.dart';

/// Conservative offline normalization for Hindi dataset retrieval.
/// This performs text matching only; it is not a linguistic parser.
class HindiNlpService {
  HindiNlpService({required TranslationService translationService})
      : _translationService = translationService;

  static const double autoAcceptThreshold = 0.85;
  static const double minimumScoreMargin = 0.05;
  static const int maxScoredCandidates = 50;

  final TranslationService _translationService;
  Future<void>? _indexInitialization;
  bool _indexLoaded = false;
  int _indexBuildCount = 0;
  Duration? _initializationDuration;
  Map<String, List<_NlpTranslationCandidate>> _normalizedIndex = {};
  Map<String, List<int>> _tokenIndex = {};
  List<_NlpTranslationCandidate> _candidates = [];

  bool get isIndexLoaded => _indexLoaded;

  /// Exposed for local diagnostics and tests; it never triggers index loading.
  int get indexBuildCount => _indexBuildCount;

  Duration? get indexInitializationTime => _initializationDuration;

  HindiTextAnalysis analyze(String text) {
    final normalized = normalize(text);
    return HindiTextAnalysis(
      originalText: text,
      normalizedText: normalized,
      tokens: tokenizeNormalized(normalized),
    );
  }

  /// Normalizes whitespace and punctuation and safely unifies common
  /// precomposed Devanagari nukta letters with their decomposed forms.
  String normalize(String text) {
    var value = text.trim().toLowerCase();
    const canonicalNuktaForms = {
      'क़': 'क़',
      'ख़': 'ख़',
      'ग़': 'ग़',
      'ज़': 'ज़',
      'ड़': 'ड़',
      'ढ़': 'ढ़',
      'फ़': 'फ़',
      'य़': 'य़',
    };
    for (final entry in canonicalNuktaForms.entries) {
      value = value.replaceAll(entry.key, entry.value);
    }

    value = value.replaceAll(RegExp(r'[।॥]'), ' ');
    value = value.replaceAll(
      RegExp(r'[^\u0900-\u097F\uA8E0-\uA8FFA-Za-z0-9]+'),
      ' ',
    );
    return value.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  List<String> tokenize(String text) => tokenizeNormalized(normalize(text));

  List<String> tokenizeNormalized(String normalizedText) =>
      normalizedText.isEmpty
          ? const []
          : List<String>.unmodifiable(normalizedText.split(' '));

  /// Existing exact dataset lookup always runs first. Normalized and
  /// similarity retrieval are attempted only after that exact path misses.
  Future<NlpTranslationResult> translateHindiToMundari(
      String sourceText) async {
    final exactWatch = Stopwatch()..start();
    final exact =
        await _translationService.translateHindiToMundari(sourceText.trim());
    exactWatch.stop();
    if (exact != null) {
      return NlpTranslationResult(
        sourceText: sourceText,
        matchedHindi: sourceText.trim(),
        translatedText: exact,
        score: 1,
        matchType: NlpMatchType.exact,
        isConfident: true,
        isAmbiguous: false,
        exactLookupTime: exactWatch.elapsed,
      );
    }

    final normalizedInput = normalize(sourceText);
    if (normalizedInput.isEmpty) {
      return NlpTranslationResult.none(
        sourceText: sourceText,
        exactLookupTime: exactWatch.elapsed,
      );
    }

    final indexWasLoaded = _indexLoaded;
    final initializationWatch = Stopwatch()..start();
    await _ensureIndex();
    initializationWatch.stop();
    final initializationTime =
        indexWasLoaded ? null : initializationWatch.elapsed;

    final normalizedMatches = _normalizedIndex[normalizedInput];
    if (normalizedMatches != null && normalizedMatches.isNotEmpty) {
      final translations =
          normalizedMatches.map((candidate) => candidate.mundari).toSet();
      if (translations.length > 1) {
        return NlpTranslationResult(
          sourceText: sourceText,
          matchedHindi: normalizedMatches.first.hindi,
          translatedText: null,
          score: 1,
          matchType: NlpMatchType.ambiguous,
          isConfident: false,
          isAmbiguous: true,
          exactLookupTime: exactWatch.elapsed,
          indexInitializationTime: initializationTime,
        );
      }
      return NlpTranslationResult(
        sourceText: sourceText,
        matchedHindi: normalizedMatches.first.hindi,
        translatedText: normalizedMatches.first.mundari,
        score: 1,
        matchType: NlpMatchType.normalizedExact,
        isConfident: true,
        isAmbiguous: false,
        exactLookupTime: exactWatch.elapsed,
        indexInitializationTime: initializationTime,
      );
    }

    final retrievalWatch = Stopwatch()..start();
    final queryTokens = normalize(sourceText).split(' ').toSet();
    final matchingCandidateIds = <int>{};
    for (final token in queryTokens) {
      matchingCandidateIds.addAll(_tokenIndex[token] ?? const <int>[]);
    }
    if (matchingCandidateIds.isEmpty || queryTokens.isEmpty) {
      retrievalWatch.stop();
      return NlpTranslationResult.none(
        sourceText: sourceText,
        score: 0,
        exactLookupTime: exactWatch.elapsed,
        indexInitializationTime: initializationTime,
        retrievalTime: retrievalWatch.elapsed,
      );
    }

    final scored = <_ScoredCandidate>[];
    for (final candidateId in matchingCandidateIds) {
      final candidate = _candidates[candidateId];
      var intersection = 0;
      for (final token in candidate.tokenSet) {
        if (queryTokens.contains(token)) intersection++;
      }
      final union =
          queryTokens.length + candidate.tokenSet.length - intersection;
      if (union == 0) continue;
      final score = intersection / union;
      scored.add(_ScoredCandidate(candidate: candidate, score: score));
    }
    scored.sort((a, b) {
      final scoreOrder = b.score.compareTo(a.score);
      return scoreOrder != 0
          ? scoreOrder
          : a.candidate.datasetOrder.compareTo(b.candidate.datasetOrder);
    });
    final topCandidates = scored.take(maxScoredCandidates).toList();
    retrievalWatch.stop();

    if (topCandidates.isEmpty) {
      return NlpTranslationResult.none(
        sourceText: sourceText,
        score: 0,
        exactLookupTime: exactWatch.elapsed,
        indexInitializationTime: initializationTime,
        retrievalTime: retrievalWatch.elapsed,
      );
    }

    final best = topCandidates.first;
    final second = topCandidates.length > 1 ? topCandidates[1] : null;
    if (best.score < autoAcceptThreshold) {
      return NlpTranslationResult.none(
        sourceText: sourceText,
        matchedHindi: best.candidate.hindi,
        score: best.score,
        exactLookupTime: exactWatch.elapsed,
        indexInitializationTime: initializationTime,
        retrievalTime: retrievalWatch.elapsed,
      );
    }
    if (second != null && best.score - second.score < minimumScoreMargin) {
      return NlpTranslationResult(
        sourceText: sourceText,
        matchedHindi: best.candidate.hindi,
        translatedText: null,
        score: best.score,
        matchType: NlpMatchType.ambiguous,
        isConfident: false,
        isAmbiguous: true,
        exactLookupTime: exactWatch.elapsed,
        indexInitializationTime: initializationTime,
        retrievalTime: retrievalWatch.elapsed,
      );
    }

    return NlpTranslationResult(
      sourceText: sourceText,
      matchedHindi: best.candidate.hindi,
      translatedText: best.candidate.mundari,
      score: best.score,
      matchType: NlpMatchType.similarity,
      isConfident: true,
      isAmbiguous: false,
      exactLookupTime: exactWatch.elapsed,
      indexInitializationTime: initializationTime,
      retrievalTime: retrievalWatch.elapsed,
    );
  }

  Future<void> _ensureIndex() async {
    if (_indexLoaded) return;
    final ongoing = _indexInitialization;
    if (ongoing != null) {
      await ongoing;
      return;
    }
    final initialization = _buildIndex();
    _indexInitialization = initialization;
    try {
      await initialization;
    } finally {
      _indexInitialization = null;
    }
  }

  Future<void> _buildIndex() async {
    if (_indexLoaded) return;
    final watch = Stopwatch()..start();
    final rows = await _translationService.getHindiToMundariEntries();
    final normalizedIndex = <String, List<_NlpTranslationCandidate>>{};
    final tokenIndex = <String, List<int>>{};
    final candidates = <_NlpTranslationCandidate>[];
    final uniquePairs = <String>{};

    for (final row in rows) {
      final normalizedHindi = normalize(row.key);
      if (normalizedHindi.isEmpty) continue;
      final pairKey = '$normalizedHindi\u0000${row.value}';
      if (!uniquePairs.add(pairKey)) continue;
      final tokenSet = tokenizeNormalized(normalizedHindi).toSet();
      final candidate = _NlpTranslationCandidate(
        hindi: row.key,
        mundari: row.value,
        tokenSet: Set<String>.unmodifiable(tokenSet),
        datasetOrder: candidates.length,
      );
      final candidateId = candidates.length;
      candidates.add(candidate);
      normalizedIndex
          .putIfAbsent(normalizedHindi, () => <_NlpTranslationCandidate>[])
          .add(candidate);
      for (final token in tokenSet) {
        tokenIndex.putIfAbsent(token, () => <int>[]).add(candidateId);
      }
    }

    _normalizedIndex = normalizedIndex.map(
      (key, value) => MapEntry(key, List.unmodifiable(value)),
    );
    _tokenIndex = tokenIndex;
    _candidates = List.unmodifiable(candidates);
    watch.stop();
    _initializationDuration = watch.elapsed;
    _indexBuildCount++;
    _indexLoaded = true;
  }
}

@immutable
class HindiTextAnalysis {
  const HindiTextAnalysis({
    required this.originalText,
    required this.normalizedText,
    required this.tokens,
  });

  final String originalText;
  final String normalizedText;
  final List<String> tokens;
}

enum NlpMatchType { exact, normalizedExact, similarity, none, ambiguous }

@immutable
class NlpTranslationResult {
  const NlpTranslationResult({
    required this.sourceText,
    this.matchedHindi,
    required this.translatedText,
    required this.score,
    required this.matchType,
    required this.isConfident,
    required this.isAmbiguous,
    required this.exactLookupTime,
    this.indexInitializationTime,
    this.retrievalTime,
  });

  const NlpTranslationResult.none({
    required this.sourceText,
    this.matchedHindi,
    this.score = 0,
    this.exactLookupTime = Duration.zero,
    this.indexInitializationTime,
    this.retrievalTime,
  })  : translatedText = null,
        matchType = NlpMatchType.none,
        isConfident = false,
        isAmbiguous = false;

  final String sourceText;
  final String? matchedHindi;
  final String? translatedText;
  final double score;
  final NlpMatchType matchType;
  final bool isConfident;
  final bool isAmbiguous;
  final Duration exactLookupTime;
  final Duration? indexInitializationTime;
  final Duration? retrievalTime;
}

class _NlpTranslationCandidate {
  const _NlpTranslationCandidate({
    required this.hindi,
    required this.mundari,
    required this.tokenSet,
    required this.datasetOrder,
  });

  final String hindi;
  final String mundari;
  final Set<String> tokenSet;
  final int datasetOrder;
}

class _ScoredCandidate {
  const _ScoredCandidate({required this.candidate, required this.score});

  final _NlpTranslationCandidate candidate;
  final double score;
}
