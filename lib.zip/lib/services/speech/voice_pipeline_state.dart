/// Observable phases for the offline voice pipeline.
enum VoicePipelinePhase {
  idle,
  requestingPermission,
  recording,
  validatingAudio,
  sampleUnavailable,
  speechToText,
  translation,
  textToSpeech,
  completed,
  permissionDenied,
  recordingFailed,
  silentAudio,
  invalidAudio,
  sttFailed,
  translationNotFound,
  ttsUnavailable,
  unknownError,
}

enum VoiceStepStatus { notStarted, running, success, error, unavailable }

/// Small transition guard that keeps UI state changes in pipeline order.
class VoicePipelineStateMachine {
  VoicePipelinePhase _phase = VoicePipelinePhase.idle;

  VoicePipelinePhase get phase => _phase;

  static const Map<VoicePipelinePhase, Set<VoicePipelinePhase>> _allowed = {
    VoicePipelinePhase.idle: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.requestingPermission: {
      VoicePipelinePhase.recording,
      VoicePipelinePhase.permissionDenied,
      VoicePipelinePhase.recordingFailed,
      VoicePipelinePhase.unknownError,
    },
    VoicePipelinePhase.recording: {
      VoicePipelinePhase.validatingAudio,
      VoicePipelinePhase.recordingFailed,
      VoicePipelinePhase.unknownError,
    },
    VoicePipelinePhase.validatingAudio: {
      VoicePipelinePhase.sampleUnavailable,
      VoicePipelinePhase.speechToText,
      VoicePipelinePhase.silentAudio,
      VoicePipelinePhase.invalidAudio,
      VoicePipelinePhase.recordingFailed,
      VoicePipelinePhase.unknownError,
    },
    VoicePipelinePhase.speechToText: {
      VoicePipelinePhase.translation,
      VoicePipelinePhase.sttFailed,
      VoicePipelinePhase.unknownError,
    },
    VoicePipelinePhase.translation: {
      VoicePipelinePhase.textToSpeech,
      VoicePipelinePhase.translationNotFound,
      VoicePipelinePhase.unknownError,
    },
    VoicePipelinePhase.textToSpeech: {
      VoicePipelinePhase.completed,
      VoicePipelinePhase.ttsUnavailable,
      VoicePipelinePhase.unknownError,
    },
    VoicePipelinePhase.completed: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.permissionDenied: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.recordingFailed: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.silentAudio: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.invalidAudio: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.sttFailed: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.translationNotFound: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.ttsUnavailable: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.unknownError: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
    VoicePipelinePhase.sampleUnavailable: {
      VoicePipelinePhase.requestingPermission,
      VoicePipelinePhase.validatingAudio,
    },
  };

  void transitionTo(VoicePipelinePhase next) {
    if (!(_allowed[_phase]?.contains(next) ?? false)) {
      throw StateError('Invalid voice pipeline transition: $_phase → $next');
    }
    _phase = next;
  }

  void beginOfflineTest() {
    transitionTo(VoicePipelinePhase.validatingAudio);
  }
}
