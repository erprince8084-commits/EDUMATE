import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../translation/translation_service.dart';
import '../tts/tts_service.dart';
import 'speech_service.dart';
import 'voice_pipeline_state.dart';

typedef SampleAssetLister = Future<List<String>> Function();
typedef SampleMaterializer = Future<String> Function(String assetPath);
typedef AudioInspector = Future<AudioInspection> Function(String path);
typedef OfflineRecognizer = Future<String?> Function(String path);
typedef ExactHindiTranslator = Future<String?> Function(String text);
typedef MundariVoiceCheck = Future<bool> Function();
typedef MundariVoicePlayback = Future<void> Function(String text);

/// Runs the local processing stages against an already-bundled WAV sample.
/// This class has no microphone or permission dependency by design.
class OfflinePipelineTestRunner {
  OfflinePipelineTestRunner({
    required VoicePipelineStateMachine stateMachine,
    required SampleAssetLister listSampleAssets,
    required SampleMaterializer materializeSample,
    required AudioInspector inspectAudio,
    required OfflineRecognizer recognizeAudio,
    required ExactHindiTranslator translateHindi,
    required MundariVoiceCheck hasOfflineMundariVoice,
    required MundariVoicePlayback speakMundari,
  })  : _stateMachine = stateMachine,
        _listSampleAssets = listSampleAssets,
        _materializeSample = materializeSample,
        _inspectAudio = inspectAudio,
        _recognizeAudio = recognizeAudio,
        _translateHindi = translateHindi,
        _hasOfflineMundariVoice = hasOfflineMundariVoice,
        _speakMundari = speakMundari;

  factory OfflinePipelineTestRunner.production({
    required VoicePipelineStateMachine stateMachine,
    required SpeechService speechService,
    required TranslationService translationService,
    required TtsService ttsService,
    AssetBundle? assetBundle,
  }) {
    final bundle = assetBundle ?? rootBundle;
    return OfflinePipelineTestRunner(
      stateMachine: stateMachine,
      listSampleAssets: () async {
        final manifest = await AssetManifest.loadFromAssetBundle(bundle);
        final samples = manifest
            .listAssets()
            .where((asset) =>
                asset.startsWith('assets/audio/') &&
                asset.toLowerCase().endsWith('.wav'))
            .toList()
          ..sort();
        return samples;
      },
      materializeSample: (assetPath) async {
        final data = await bundle.load(assetPath);
        final directory = await getTemporaryDirectory();
        final filename = p.basename(assetPath);
        final file = File(p.join(directory.path, 'edumate_test_$filename'));
        await file.writeAsBytes(
          data.buffer.asUint8List(
            data.offsetInBytes,
            data.lengthInBytes,
          ),
          flush: true,
        );
        return file.path;
      },
      inspectAudio: SpeechService.inspectWavFile,
      recognizeAudio: speechService.recognizeAudio,
      translateHindi: translationService.translateHindiToMundari,
      hasOfflineMundariVoice: ttsService.isOfflineMundariAvailable,
      speakMundari: (text) async {
        await ttsService.speakMundari(text);
      },
    );
  }

  final VoicePipelineStateMachine _stateMachine;
  final SampleAssetLister _listSampleAssets;
  final SampleMaterializer _materializeSample;
  final AudioInspector _inspectAudio;
  final OfflineRecognizer _recognizeAudio;
  final ExactHindiTranslator _translateHindi;
  final MundariVoiceCheck _hasOfflineMundariVoice;
  final MundariVoicePlayback _speakMundari;

  Future<OfflinePipelineTestResult> run({
    void Function(VoicePipelinePhase phase)? onPhaseChanged,
  }) async {
    final totalWatch = Stopwatch()..start();
    String? localSamplePath;
    String? sampleAsset;
    AudioInspection? audio;
    Duration? validationTime;
    Duration? sttTime;
    Duration? translationTime;
    Duration? ttsTime;
    String? recognizedText;
    String? mundariText;
    var sttStatus = VoiceStepStatus.notStarted;
    var translationStatus = VoiceStepStatus.notStarted;
    var ttsStatus = VoiceStepStatus.notStarted;

    void phase(VoicePipelinePhase next) {
      _stateMachine.transitionTo(next);
      onPhaseChanged?.call(next);
    }

    try {
      phase(VoicePipelinePhase.validatingAudio);
      final assets = await _listSampleAssets();
      if (assets.isEmpty) {
        phase(VoicePipelinePhase.sampleUnavailable);
        totalWatch.stop();
        return OfflinePipelineTestResult(
          sampleAsset: null,
          audio: null,
          recognizedText: null,
          mundariText: null,
          sttStatus: VoiceStepStatus.notStarted,
          translationStatus: VoiceStepStatus.notStarted,
          ttsStatus: VoiceStepStatus.notStarted,
          validationTime: null,
          sttTime: null,
          translationTime: null,
          ttsTime: null,
          totalTime: totalWatch.elapsed,
          error:
              'No bundled Hindi speech sample is available yet. Add a real Hindi speech WAV sample to assets/audio/ to test offline STT.',
          microphoneBypassed: true,
        );
      }

      sampleAsset = assets.first;
      localSamplePath = await _materializeSample(sampleAsset);
      final validationWatch = Stopwatch()..start();
      audio = await _inspectAudio(localSamplePath);
      validationWatch.stop();
      validationTime = validationWatch.elapsed;

      if (!audio.fileExists || !audio.isValidWav) {
        phase(VoicePipelinePhase.invalidAudio);
        totalWatch.stop();
        return _result(
          sampleAsset,
          audio,
          recognizedText,
          mundariText,
          sttStatus,
          translationStatus,
          ttsStatus,
          validationTime,
          sttTime,
          translationTime,
          ttsTime,
          totalWatch.elapsed,
          audio.error ?? 'The bundled audio sample is invalid.',
        );
      }
      if (!audio.hasUsableSignal) {
        phase(VoicePipelinePhase.silentAudio);
        totalWatch.stop();
        return _result(
          sampleAsset,
          audio,
          recognizedText,
          mundariText,
          sttStatus,
          translationStatus,
          ttsStatus,
          validationTime,
          sttTime,
          translationTime,
          ttsTime,
          totalWatch.elapsed,
          audio.error ?? 'The bundled WAV has no usable audio signal.',
        );
      }

      phase(VoicePipelinePhase.speechToText);
      sttStatus = VoiceStepStatus.running;
      onPhaseChanged?.call(_stateMachine.phase);
      final sttWatch = Stopwatch()..start();
      try {
        recognizedText = await _recognizeAudio(localSamplePath);
      } catch (error) {
        sttWatch.stop();
        sttTime = sttWatch.elapsed;
        sttStatus = VoiceStepStatus.error;
        phase(VoicePipelinePhase.sttFailed);
        totalWatch.stop();
        return _result(
          sampleAsset,
          audio,
          null,
          null,
          sttStatus,
          translationStatus,
          ttsStatus,
          validationTime,
          sttTime,
          translationTime,
          ttsTime,
          totalWatch.elapsed,
          'Offline Hindi speech recognition failed. $error',
        );
      }
      sttWatch.stop();
      sttTime = sttWatch.elapsed;
      if (recognizedText == null || recognizedText.trim().isEmpty) {
        sttStatus = VoiceStepStatus.error;
        phase(VoicePipelinePhase.sttFailed);
        totalWatch.stop();
        return _result(
          sampleAsset,
          audio,
          null,
          null,
          sttStatus,
          translationStatus,
          ttsStatus,
          validationTime,
          sttTime,
          translationTime,
          ttsTime,
          totalWatch.elapsed,
          'Offline Hindi speech recognition returned no text.',
        );
      }
      recognizedText = recognizedText.trim();
      sttStatus = VoiceStepStatus.success;

      phase(VoicePipelinePhase.translation);
      translationStatus = VoiceStepStatus.running;
      onPhaseChanged?.call(_stateMachine.phase);
      final translationWatch = Stopwatch()..start();
      mundariText = await _translateHindi(recognizedText);
      translationWatch.stop();
      translationTime = translationWatch.elapsed;
      if (mundariText == null || mundariText.trim().isEmpty) {
        translationStatus = VoiceStepStatus.error;
        phase(VoicePipelinePhase.translationNotFound);
        totalWatch.stop();
        return _result(
          sampleAsset,
          audio,
          recognizedText,
          null,
          sttStatus,
          translationStatus,
          ttsStatus,
          validationTime,
          sttTime,
          translationTime,
          ttsTime,
          totalWatch.elapsed,
          'No exact Hindi→Mundari translation was found in the current offline dataset.',
        );
      }
      mundariText = mundariText.trim();
      translationStatus = VoiceStepStatus.success;

      phase(VoicePipelinePhase.textToSpeech);
      final voiceAvailable = await _hasOfflineMundariVoice();
      if (!voiceAvailable) {
        ttsStatus = VoiceStepStatus.unavailable;
        phase(VoicePipelinePhase.ttsUnavailable);
        totalWatch.stop();
        return _result(
          sampleAsset,
          audio,
          recognizedText,
          mundariText,
          sttStatus,
          translationStatus,
          ttsStatus,
          validationTime,
          sttTime,
          translationTime,
          ttsTime,
          totalWatch.elapsed,
          'No usable offline Mundari voice is available on this device.',
        );
      }

      ttsStatus = VoiceStepStatus.running;
      onPhaseChanged?.call(_stateMachine.phase);
      final ttsWatch = Stopwatch()..start();
      try {
        await _speakMundari(mundariText);
        ttsWatch.stop();
        ttsTime = ttsWatch.elapsed;
        ttsStatus = VoiceStepStatus.success;
        phase(VoicePipelinePhase.completed);
      } catch (error) {
        ttsWatch.stop();
        ttsTime = ttsWatch.elapsed;
        ttsStatus = VoiceStepStatus.error;
        phase(VoicePipelinePhase.unknownError);
        totalWatch.stop();
        return _result(
          sampleAsset,
          audio,
          recognizedText,
          mundariText,
          sttStatus,
          translationStatus,
          ttsStatus,
          validationTime,
          sttTime,
          translationTime,
          ttsTime,
          totalWatch.elapsed,
          'Mundari TTS playback failed. $error',
        );
      }

      totalWatch.stop();
      return _result(
        sampleAsset,
        audio,
        recognizedText,
        mundariText,
        sttStatus,
        translationStatus,
        ttsStatus,
        validationTime,
        sttTime,
        translationTime,
        ttsTime,
        totalWatch.elapsed,
        null,
      );
    } catch (error) {
      totalWatch.stop();
      if (_stateMachine.phase == VoicePipelinePhase.speechToText) {
        sttStatus = VoiceStepStatus.error;
      } else if (_stateMachine.phase == VoicePipelinePhase.translation) {
        translationStatus = VoiceStepStatus.error;
      } else if (_stateMachine.phase == VoicePipelinePhase.textToSpeech) {
        ttsStatus = VoiceStepStatus.error;
      }
      if (_stateMachine.phase != VoicePipelinePhase.unknownError &&
          _stateMachine.phase != VoicePipelinePhase.sampleUnavailable &&
          _stateMachine.phase != VoicePipelinePhase.invalidAudio &&
          _stateMachine.phase != VoicePipelinePhase.silentAudio &&
          _stateMachine.phase != VoicePipelinePhase.sttFailed &&
          _stateMachine.phase != VoicePipelinePhase.translationNotFound &&
          _stateMachine.phase != VoicePipelinePhase.ttsUnavailable &&
          _stateMachine.phase != VoicePipelinePhase.completed) {
        phase(VoicePipelinePhase.unknownError);
      }
      return _result(
        sampleAsset,
        audio,
        recognizedText,
        mundariText,
        sttStatus,
        translationStatus,
        ttsStatus,
        validationTime,
        sttTime,
        translationTime,
        ttsTime,
        totalWatch.elapsed,
        'Offline pipeline test failed. $error',
      );
    } finally {
      if (localSamplePath != null) {
        try {
          final file = File(localSamplePath);
          if (await file.exists()) await file.delete();
        } catch (_) {
          // Temporary sample cleanup must not hide the pipeline result.
        }
      }
    }
  }

  OfflinePipelineTestResult _result(
    String? sampleAsset,
    AudioInspection? audio,
    String? recognizedText,
    String? mundariText,
    VoiceStepStatus sttStatus,
    VoiceStepStatus translationStatus,
    VoiceStepStatus ttsStatus,
    Duration? validationTime,
    Duration? sttTime,
    Duration? translationTime,
    Duration? ttsTime,
    Duration totalTime,
    String? error,
  ) =>
      OfflinePipelineTestResult(
        sampleAsset: sampleAsset,
        audio: audio,
        recognizedText: recognizedText,
        mundariText: mundariText,
        sttStatus: sttStatus,
        translationStatus: translationStatus,
        ttsStatus: ttsStatus,
        validationTime: validationTime,
        sttTime: sttTime,
        translationTime: translationTime,
        ttsTime: ttsTime,
        totalTime: totalTime,
        error: error,
        microphoneBypassed: true,
      );
}

class OfflinePipelineTestResult {
  const OfflinePipelineTestResult({
    required this.sampleAsset,
    required this.audio,
    required this.recognizedText,
    required this.mundariText,
    required this.sttStatus,
    required this.translationStatus,
    required this.ttsStatus,
    required this.validationTime,
    required this.sttTime,
    required this.translationTime,
    required this.ttsTime,
    required this.totalTime,
    required this.error,
    required this.microphoneBypassed,
  });

  final String? sampleAsset;
  final AudioInspection? audio;
  final String? recognizedText;
  final String? mundariText;
  final VoiceStepStatus sttStatus;
  final VoiceStepStatus translationStatus;
  final VoiceStepStatus ttsStatus;
  final Duration? validationTime;
  final Duration? sttTime;
  final Duration? translationTime;
  final Duration? ttsTime;
  final Duration totalTime;
  final String? error;
  final bool microphoneBypassed;
}
