import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:sherpa_onnx/sherpa_onnx.dart' as sherpa;

class SpeechService {
  final AudioRecorder _recorder = AudioRecorder();

  bool _isRecording = false;
  bool _isRecognizerReady = false;

  sherpa.OfflineRecognizer? _recognizer;

  bool get isRecording => _isRecording;
  bool get isRecognizerReady => _isRecognizerReady;
  Future<void>? _recognizerInitialization;

  Future<bool> requestPermission() async {
    final permission = await Permission.microphone.request();
    if (!permission.isGranted) return false;
    return _recorder.hasPermission();
  }

  Future<String> _copyAssetToLocalStorage(
    String assetPath,
    String fileName,
  ) async {
    final directory = await getApplicationSupportDirectory();

    final modelDirectory = Directory(
      p.join(directory.path, 'models', 'hindi'),
    );

    if (!await modelDirectory.exists()) {
      await modelDirectory.create(recursive: true);
    }

    final destinationPath = p.join(
      modelDirectory.path,
      fileName,
    );

    final destinationFile = File(destinationPath);

    if (await destinationFile.exists()) {
      return destinationPath;
    }

    final byteData = await rootBundle.load(assetPath);

    final bytes = byteData.buffer.asUint8List(
      byteData.offsetInBytes,
      byteData.lengthInBytes,
    );

    await destinationFile.writeAsBytes(
      bytes,
      flush: true,
    );

    return destinationPath;
  }

  Future<void> initializeRecognizer() async {
    if (_isRecognizerReady) {
      return;
    }

    final ongoingInitialization = _recognizerInitialization;
    if (ongoingInitialization != null) {
      await ongoingInitialization;
      return;
    }
    final initialization = _initializeRecognizerOnce();
    _recognizerInitialization = initialization;
    try {
      await initialization;
    } finally {
      _recognizerInitialization = null;
    }
  }

  Future<void> _initializeRecognizerOnce() async {
    if (_isRecognizerReady) return;

    sherpa.initBindings();

    const modelAsset = 'assets/models/hindi/model.int8.onnx';
    const tokensAsset = 'assets/models/hindi/tokens.txt';

    final modelPath = await _copyAssetToLocalStorage(
      modelAsset,
      'model.int8.onnx',
    );

    final tokensPath = await _copyAssetToLocalStorage(
      tokensAsset,
      'tokens.txt',
    );

    final nemoCtc = sherpa.OfflineNemoEncDecCtcModelConfig(
      model: modelPath,
    );

    final modelConfig = sherpa.OfflineModelConfig(
      nemoCtc: nemoCtc,
      tokens: tokensPath,
      numThreads: 2,
      provider: 'cpu',
    );

    final recognizerConfig = sherpa.OfflineRecognizerConfig(
      model: modelConfig,
      decodingMethod: 'greedy_search',
    );

    _recognizer = sherpa.OfflineRecognizer(
      recognizerConfig,
    );

    _isRecognizerReady = true;
  }

  Future<String?> startRecording(
      {bool permissionAlreadyGranted = false}) async {
    final hasPermission = permissionAlreadyGranted || await requestPermission();

    if (!hasPermission) {
      return null;
    }

    final directory = await getTemporaryDirectory();

    final filePath = '${directory.path}/edumate_voice_test.wav';
    final oldRecording = File(filePath);
    if (await oldRecording.exists()) await oldRecording.delete();

    const config = RecordConfig(
      encoder: AudioEncoder.wav,
      sampleRate: 16000,
      numChannels: 1,
      androidConfig: AndroidRecordConfig(
        audioSource: AndroidAudioSource.mic,
        audioManagerMode: AudioManagerMode.modeNormal,
        manageBluetooth: false,
        muteAudio: false,
        speakerphone: false,
      ),
      autoGain: false,
      echoCancel: false,
      noiseSuppress: false,
    );

    await _recorder.start(
      config,
      path: filePath,
    );

    _isRecording = true;

    return filePath;
  }

  Future<String?> stopRecording() async {
    if (!_isRecording) {
      return null;
    }

    final path = await _recorder.stop();

    _isRecording = false;

    if (path == null) {
      return null;
    }

    final file = File(path);

    if (!await file.exists()) {
      return null;
    }

    return path;
  }

  /// Inspects captured WAV audio before it is sent to the offline recognizer.
  /// This reads the bounded recording file, never the 188 MB model asset.
  static Future<AudioInspection> inspectWavFile(String audioPath) async {
    try {
      if (audioPath.trim().isEmpty) {
        return const AudioInspection.invalid('Recording path is empty.');
      }
      final file = File(audioPath);
      if (!await file.exists()) {
        return const AudioInspection.invalid('Recorded audio file is missing.');
      }

      final fileSize = await file.length();
      if (fileSize < 44) {
        return AudioInspection.invalid('Recorded WAV file is incomplete.',
            fileExists: true, fileSize: fileSize);
      }
      if (fileSize > 24 * 1024 * 1024) {
        return AudioInspection.invalid(
            'Recording is too large to inspect safely.',
            fileExists: true,
            fileSize: fileSize);
      }

      final bytes = await file.readAsBytes();
      String chunkName(int offset) =>
          String.fromCharCodes(bytes.sublist(offset, offset + 4));
      if (chunkName(0) != 'RIFF' || chunkName(8) != 'WAVE') {
        return AudioInspection.invalid(
            'Recorded audio is not a valid RIFF/WAVE file.',
            fileExists: true,
            fileSize: fileSize);
      }

      final data = ByteData.sublistView(bytes);
      final riffLength = data.getUint32(4, Endian.little);
      if (riffLength < 36 || riffLength > fileSize - 8) {
        return AudioInspection.invalid(
          'RIFF/WAV header length is invalid.',
          fileExists: true,
          fileSize: fileSize,
        );
      }
      int? format;
      int? channels;
      int? sampleRate;
      int? bitsPerSample;
      int? samplesOffset;
      int? samplesLength;

      var offset = 12;
      while (offset + 8 <= bytes.length) {
        final chunk = chunkName(offset);
        final size = data.getUint32(offset + 4, Endian.little);
        final start = offset + 8;
        if (size < 0 || start + size > bytes.length) break;

        if (chunk == 'fmt ' && size >= 16) {
          format = data.getUint16(start, Endian.little);
          channels = data.getUint16(start + 2, Endian.little);
          sampleRate = data.getUint32(start + 4, Endian.little);
          bitsPerSample = data.getUint16(start + 14, Endian.little);
        } else if (chunk == 'data') {
          samplesOffset = start;
          samplesLength = size;
        }
        offset = start + size + (size.isOdd ? 1 : 0);
      }

      if (format == null ||
          channels == null ||
          sampleRate == null ||
          bitsPerSample == null ||
          samplesOffset == null ||
          samplesLength == null) {
        return AudioInspection.invalid(
            'WAV format or PCM audio data is missing.',
            fileExists: true,
            fileSize: fileSize);
      }
      if (format != 1 ||
          channels != 1 ||
          sampleRate != 16000 ||
          bitsPerSample != 16 ||
          samplesLength.isOdd) {
        return AudioInspection.invalid(
          'Audio format must be mono 16 kHz PCM WAV.',
          fileExists: true,
          fileSize: fileSize,
          sampleRate: sampleRate,
          channels: channels,
          bitsPerSample: bitsPerSample,
        );
      }

      final sampleCount = samplesLength ~/ 2;
      if (sampleCount < 4000) {
        return AudioInspection.invalid('Recording is too short to recognize.',
            fileExists: true,
            fileSize: fileSize,
            sampleRate: sampleRate,
            channels: channels,
            bitsPerSample: bitsPerSample,
            sampleCount: sampleCount);
      }

      var sumSquares = 0.0;
      var peak = 0.0;
      for (var i = 0; i < sampleCount; i++) {
        final value =
            data.getInt16(samplesOffset + i * 2, Endian.little) / 32768.0;
        final absolute = value.abs();
        if (absolute > peak) peak = absolute;
        sumSquares += value * value;
      }
      final rms = math.sqrt(sumSquares / sampleCount);
      final usable = rms >= 0.003 && peak >= 0.015;
      return AudioInspection(
        fileExists: true,
        isValidWav: true,
        hasUsableSignal: usable,
        fileSize: fileSize,
        sampleRate: sampleRate,
        channels: channels,
        bitsPerSample: bitsPerSample,
        sampleCount: sampleCount,
        durationSeconds: sampleCount / sampleRate,
        rmsAmplitude: rms,
        peakAmplitude: peak,
        error: usable
            ? null
            : 'Audio captured, but no usable microphone signal was detected.',
      );
    } catch (_) {
      return const AudioInspection.invalid(
          'Could not inspect the recorded audio file.');
    }
  }

  Future<String?> recognizeAudio(
    String audioPath,
  ) async {
    final inspection = await inspectWavFile(audioPath);
    if (!inspection.isValidWav || !inspection.hasUsableSignal) {
      throw StateError(
          inspection.error ?? 'Audio does not contain a usable signal.');
    }

    await initializeRecognizer();

    if (_recognizer == null) {
      return null;
    }

    final file = File(audioPath);

    if (!await file.exists()) {
      return null;
    }

    final wave = sherpa.readWave(audioPath);

    if (wave.samples.isEmpty) {
      return null;
    }

    final stream = _recognizer!.createStream();
    try {
      stream.acceptWaveform(
        samples: wave.samples,
        sampleRate: wave.sampleRate,
      );
      _recognizer!.decode(stream);
      final result = _recognizer!.getResult(stream);
      final text = result.text.trim();
      return text.isEmpty ? null : text;
    } finally {
      stream.free();
    }
  }

  Future<void> dispose() async {
    _recognizer?.free();

    _recognizer = null;
    _isRecognizerReady = false;

    await _recorder.dispose();
  }
}

class AudioInspection {
  const AudioInspection({
    required this.fileExists,
    required this.isValidWav,
    required this.hasUsableSignal,
    this.fileSize = 0,
    this.sampleRate,
    this.channels,
    this.bitsPerSample,
    this.sampleCount = 0,
    this.durationSeconds = 0,
    this.rmsAmplitude = 0,
    this.peakAmplitude = 0,
    this.error,
  });

  const AudioInspection.invalid(
    String message, {
    this.fileExists = false,
    this.fileSize = 0,
    this.sampleRate,
    this.channels,
    this.bitsPerSample,
    this.sampleCount = 0,
    this.durationSeconds = 0,
  })  : isValidWav = false,
        hasUsableSignal = false,
        rmsAmplitude = 0,
        peakAmplitude = 0,
        error = message;

  final bool fileExists;
  final bool isValidWav;
  final bool hasUsableSignal;
  final int fileSize;
  final int? sampleRate;
  final int? channels;
  final int? bitsPerSample;
  final int sampleCount;
  final double durationSeconds;
  final double rmsAmplitude;
  final double peakAmplitude;
  final String? error;
}
