import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class WorksheetQuestion {
  const WorksheetQuestion({required this.hindi, required this.mundari});

  final String hindi;
  final String mundari;
}

class WorksheetContent {
  const WorksheetContent({
    required this.title,
    required this.grade,
    required this.subject,
    required this.topic,
    required this.hindiContent,
    required this.mundariContent,
    required this.questions,
  });

  final String title;
  final String grade;
  final String subject;
  final String topic;
  final String hindiContent;
  final String mundariContent;
  final List<WorksheetQuestion> questions;
}

class WorksheetService {
  Future<Uint8List> generatePdf(WorksheetContent worksheet) async {
    final document = pw.Document();
    final fontData = await rootBundle.load('assets/fonts/DevanagariMT.ttf');
    final font = pw.Font.ttf(fontData);
    final boldFont = pw.Font.ttf(fontData);

    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(38),
        theme: pw.ThemeData.withFont(base: font, bold: boldFont),
        build: (context) => [
          pw.Center(
            child: pw.Column(children: [
              pw.Text('EDUMATE', style: pw.TextStyle(fontSize: 21, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 4),
              pw.Text('Bilingual Learning Worksheet', style: const pw.TextStyle(fontSize: 15)),
            ]),
          ),
          pw.SizedBox(height: 20),
          pw.Text(worksheet.title, style: pw.TextStyle(fontSize: 19, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 10),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400),
            children: [
              _metadataRow('Class', worksheet.grade, 'Subject', worksheet.subject),
              _metadataRow('Lesson / Topic', worksheet.topic, '', ''),
            ],
          ),
          pw.SizedBox(height: 18),
          _section('Hindi section', worksheet.hindiContent),
          pw.SizedBox(height: 12),
          _section('Mundari section', worksheet.mundariContent),
          pw.SizedBox(height: 20),
          pw.Text('Questions', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          ...worksheet.questions.indexed.map((entry) {
            final (index, question) = entry;
            return pw.Container(
              width: double.infinity,
              margin: const pw.EdgeInsets.only(bottom: 10),
              padding: const pw.EdgeInsets.all(10),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey400),
                borderRadius: pw.BorderRadius.circular(5),
              ),
              child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('${index + 1}. Hindi: ${question.hindi}', style: const pw.TextStyle(fontSize: 12)),
                pw.SizedBox(height: 5),
                pw.Text('   Mundari: ${question.mundari}', style: const pw.TextStyle(fontSize: 12)),
                pw.SizedBox(height: 18),
              ]),
            );
          }),
        ],
      ),
    );
    return document.save();
  }

  pw.TableRow _metadataRow(String label1, String value1, String label2, String value2) {
    return pw.TableRow(children: [
      _cell(label1, bold: true),
      _cell(value1),
      if (label2.isNotEmpty) _cell(label2, bold: true),
      if (label2.isNotEmpty) _cell(value2),
    ]);
  }

  pw.Widget _cell(String value, {bool bold = false}) => pw.Padding(
        padding: const pw.EdgeInsets.all(8),
        child: pw.Text(value, style: pw.TextStyle(fontSize: 10, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
      );

  pw.Widget _section(String title, String body) => pw.Container(
        width: double.infinity,
        padding: const pw.EdgeInsets.all(12),
        decoration: pw.BoxDecoration(
          color: PdfColors.grey100,
          border: pw.Border.all(color: PdfColors.grey400),
          borderRadius: pw.BorderRadius.circular(5),
        ),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text(title, style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          pw.Text(body, style: const pw.TextStyle(fontSize: 12, lineSpacing: 4)),
        ]),
      );
}
