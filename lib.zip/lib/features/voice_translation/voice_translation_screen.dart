import 'dart:async';

import 'package:flutter/material.dart';

import '../../services/speech/offline_pipeline_test_runner.dart';
import '../../services/speech/speech_service.dart';
import '../../services/speech/voice_pipeline_state.dart';
import '../../services/translation/translation_service.dart';
import '../../services/tts/tts_service.dart';

class VoiceTranslationScreen extends StatefulWidget {
  const VoiceTranslationScreen({super.key});

  @override
  State<VoiceTranslationScreen> createState() => _VoiceTranslationScreenState();
}

class _TargetValidationNote extends StatelessWidget {
  const _TargetValidationNote();

  @override
  Widget build(BuildContext context) => const Text(
        'SIH end-to-end <3s target: Not yet validated on physical target hardware.',
      );
}

class _VoiceTranslationScreenState extends State<VoiceTranslationScreen> {
  final SpeechService _speech = SpeechService();
  final TranslationService _translation = TranslationService();
  final TtsService _tts = TtsService();
  late final OfflinePipelineTestRunner _offlineTestRunner =
      OfflinePipelineTestRunner.production(
    stateMachine: _pipeline,
    speechService: _speech,
    translationService: _translation,
    ttsService: _tts,
  );

  Timer? _recordTimer;
  Stopwatch? _recordWatch;
  final VoicePipelineStateMachine _pipeline = VoicePipelineStateMachine();
  bool _recording = false;
  bool _processing = false;
  bool _testModeActive = false;
  bool? _permissionGranted;
  bool _ttsAvailable = false;
  bool _ttsChecked = false;
  String _mainStatus = 'Tap microphone to start';
  String? _error;
  String? _recognized;
  String? _mundari;
  AudioInspection? _audio;
  OfflinePipelineTestResult? _offlineTestResult;
  Duration? _recordDuration;
  Duration? _validationTime;
  Duration? _sttTime;
  Duration? _translationTime;
  Duration? _ttsTime;
  Duration? _totalTime;
  VoiceStepStatus _micStage = VoiceStepStatus.notStarted;
  VoiceStepStatus _sttStage = VoiceStepStatus.notStarted;
  VoiceStepStatus _translationStage = VoiceStepStatus.notStarted;
  VoiceStepStatus _ttsStage = VoiceStepStatus.running;
  VoiceStepStatus _completeStage = VoiceStepStatus.notStarted;

  @override
  void initState() {
    super.initState();
    _checkTts();
  }

  Future<void> _checkTts() async {
    try {
      final available = await _tts.isOfflineMundariAvailable();
      if (!mounted) return;
      setState(() {
        _ttsAvailable = available;
        _ttsChecked = true;
        _ttsStage = available
            ? VoiceStepStatus.notStarted
            : VoiceStepStatus.unavailable;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _ttsChecked = true;
        _ttsStage = VoiceStepStatus.unavailable;
      });
    }
  }

  Future<void> _startRecording() async {
    _pipeline.transitionTo(VoicePipelinePhase.requestingPermission);
    setState(() {
      _offlineTestResult = null;
      _testModeActive = false;
      _micStage = VoiceStepStatus.running;
      _sttStage = VoiceStepStatus.notStarted;
      _translationStage = VoiceStepStatus.notStarted;
      _ttsStage = _ttsAvailable
          ? VoiceStepStatus.notStarted
          : VoiceStepStatus.unavailable;
      _completeStage = VoiceStepStatus.notStarted;
      _error = null;
      _recognized = null;
      _mundari = null;
      _audio = null;
      _recordDuration = null;
      _validationTime = null;
      _sttTime = null;
      _translationTime = null;
      _ttsTime = null;
      _totalTime = null;
      _mainStatus = 'Requesting microphone permission…';
    });
    try {
      final permitted = await _speech.requestPermission();
      if (!mounted) return;
      _permissionGranted = permitted;
      if (!permitted) {
        _pipeline.transitionTo(VoicePipelinePhase.permissionDenied);
        setState(() {
          _micStage = VoiceStepStatus.unavailable;
          _mainStatus = 'Microphone permission was denied.';
        });
        return;
      }
      final path = await _speech.startRecording(permissionAlreadyGranted: true);
      if (!mounted) return;
      if (path == null) {
        throw StateError('The microphone recorder did not start.');
      }
      _pipeline.transitionTo(VoicePipelinePhase.recording);
      _recordWatch = Stopwatch()..start();
      setState(() {
        _recording = true;
        _micStage = VoiceStepStatus.running;
        _mainStatus = 'Listening…';
      });
      _recordTimer?.cancel();
      _recordTimer = Timer.periodic(const Duration(milliseconds: 250), (_) {
        if (mounted) setState(() {});
        if ((_recordWatch?.elapsed ?? Duration.zero) >=
            const Duration(seconds: 60)) {
          _stopAndProcess();
        }
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _recording = false;
        if (_pipeline.phase == VoicePipelinePhase.requestingPermission) {
          _pipeline.transitionTo(VoicePipelinePhase.recordingFailed);
        }
        _micStage = VoiceStepStatus.error;
        _completeStage = VoiceStepStatus.error;
        _mainStatus = 'Recording could not start.';
        _error = _friendly(error);
      });
    }
  }

  Future<void> _runOfflinePipelineTest() async {
    if (_recording || _processing) return;
    setState(() {
      _offlineTestResult = null;
      _testModeActive = true;
      _processing = true;
      _error = null;
      _mainStatus = 'Validating bundled sample…';
    });
    final result = await _offlineTestRunner.run(
      onPhaseChanged: (phase) {
        if (!mounted) return;
        setState(() {
          _mainStatus = _phaseLabel(phase);
          if (phase == VoicePipelinePhase.validatingAudio) {
            _micStage = VoiceStepStatus.unavailable;
          } else if (phase == VoicePipelinePhase.speechToText) {
            _sttStage = VoiceStepStatus.running;
          } else if (phase == VoicePipelinePhase.translation) {
            _sttStage = VoiceStepStatus.success;
            _translationStage = VoiceStepStatus.running;
          } else if (phase == VoicePipelinePhase.textToSpeech) {
            _translationStage = VoiceStepStatus.success;
            _ttsStage = VoiceStepStatus.running;
          }
        });
      },
    );
    if (!mounted) return;
    setState(() {
      _offlineTestResult = result;
      _processing = false;
      _micStage = VoiceStepStatus.unavailable;
      _sttStage = result.sttStatus;
      _translationStage = result.translationStatus;
      _ttsStage = result.ttsStatus;
      _completeStage = result.sttStatus == VoiceStepStatus.success &&
              result.translationStatus == VoiceStepStatus.success &&
              result.ttsStatus == VoiceStepStatus.success
          ? VoiceStepStatus.success
          : result.ttsStatus == VoiceStepStatus.unavailable
              ? VoiceStepStatus.unavailable
              : result.error == null
                  ? VoiceStepStatus.notStarted
                  : VoiceStepStatus.error;
      _mainStatus = result.error ?? _phaseLabel(_pipeline.phase);
    });
  }

  Future<void> _stopAndProcess() async {
    if (!_recording || _processing) return;
    _recordTimer?.cancel();
    _recordWatch?.stop();
    final total = Stopwatch()..start();
    _pipeline.transitionTo(VoicePipelinePhase.validatingAudio);
    setState(() {
      _recording = false;
      _processing = true;
      _recordDuration = _recordWatch?.elapsed;
      _micStage = VoiceStepStatus.running;
      _mainStatus = 'Processing offline…';
      _error = null;
    });

    try {
      final path = await _speech.stopRecording();
      if (!mounted) return;
      if (path == null) {
        _pipeline.transitionTo(VoicePipelinePhase.recordingFailed);
        throw StateError(
            'No audio file was captured. Check microphone access and try again.');
      }
      final validationWatch = Stopwatch()..start();
      final inspection = await SpeechService.inspectWavFile(path);
      validationWatch.stop();
      if (!mounted) return;
      setState(() {
        _audio = inspection;
        _validationTime = validationWatch.elapsed;
      });
      if (!inspection.fileExists) {
        _pipeline.transitionTo(VoicePipelinePhase.invalidAudio);
        throw StateError(inspection.error ?? 'Recorded audio file is missing.');
      }
      setState(() => _micStage = VoiceStepStatus.success);
      if (!inspection.isValidWav) {
        _pipeline.transitionTo(VoicePipelinePhase.invalidAudio);
        throw StateError(
            inspection.error ?? 'The recorded WAV file is invalid.');
      }
      if (!inspection.hasUsableSignal) {
        _pipeline.transitionTo(VoicePipelinePhase.silentAudio);
        total.stop();
        setState(() {
          _processing = false;
          _totalTime = total.elapsed;
          _micStage = VoiceStepStatus.success;
          _sttStage = VoiceStepStatus.error;
          _completeStage = VoiceStepStatus.error;
          _mainStatus = 'Voice translation could not be completed';
          _error =
              'Audio captured, but no usable microphone signal was detected. Please test the microphone on a physical Android device. The current emulator may not provide a usable audio input.';
        });
        return;
      }

      _pipeline.transitionTo(VoicePipelinePhase.speechToText);
      setState(() => _sttStage = VoiceStepStatus.running);
      final sttWatch = Stopwatch()..start();
      final text = await _speech.recognizeAudio(path);
      sttWatch.stop();
      if (!mounted) return;
      _sttTime = sttWatch.elapsed;
      if (text == null || text.trim().isEmpty) {
        _pipeline.transitionTo(VoicePipelinePhase.sttFailed);
        total.stop();
        setState(() {
          _processing = false;
          _totalTime = total.elapsed;
          _sttStage = VoiceStepStatus.error;
          _completeStage = VoiceStepStatus.error;
          _mainStatus = 'Voice translation could not be completed';
          _error = 'No speech was recognized.';
        });
        return;
      }
      setState(() {
        _recognized = text.trim();
        _sttStage = VoiceStepStatus.success;
        _translationStage = VoiceStepStatus.running;
      });

      _pipeline.transitionTo(VoicePipelinePhase.translation);
      final translationWatch = Stopwatch()..start();
      final translated = await _translation.translateHindiToMundari(text);
      translationWatch.stop();
      if (!mounted) return;
      _translationTime = translationWatch.elapsed;
      if (translated == null || translated.trim().isEmpty) {
        _pipeline.transitionTo(VoicePipelinePhase.translationNotFound);
        total.stop();
        setState(() {
          _processing = false;
          _totalTime = total.elapsed;
          _translationStage = VoiceStepStatus.unavailable;
          _completeStage = VoiceStepStatus.unavailable;
          _mainStatus = 'Voice translation could not be completed';
          _mundari =
              'No exact Hindi→Mundari translation was found in the current offline dataset.';
        });
        return;
      }

      setState(() {
        _mundari = translated;
        _translationStage = VoiceStepStatus.success;
        _ttsStage = _ttsAvailable
            ? VoiceStepStatus.running
            : VoiceStepStatus.unavailable;
      });
      _pipeline.transitionTo(VoicePipelinePhase.textToSpeech);
      if (_ttsAvailable) {
        try {
          final ttsWatch = Stopwatch()..start();
          await _tts.speakMundari(translated);
          ttsWatch.stop();
          _ttsTime = ttsWatch.elapsed;
          _ttsStage = VoiceStepStatus.success;
        } catch (error) {
          _ttsStage = VoiceStepStatus.unavailable;
          _error = _friendly(error);
        }
      }
      total.stop();
      if (!mounted) return;
      setState(() {
        _totalTime = total.elapsed;
        _processing = false;
        _completeStage = _ttsStage == VoiceStepStatus.success
            ? VoiceStepStatus.success
            : VoiceStepStatus.unavailable;
        _pipeline.transitionTo(
          _ttsStage == VoiceStepStatus.success
              ? VoicePipelinePhase.completed
              : VoicePipelinePhase.ttsUnavailable,
        );
        _mainStatus = _completeStage == VoiceStepStatus.success
            ? 'Translation ready'
            : 'Translation ready; Mundari offline voice is not available on this device.';
      });
    } catch (error) {
      total.stop();
      if (!mounted) return;
      setState(() {
        _processing = false;
        _totalTime = total.elapsed;
        if (_pipeline.phase == VoicePipelinePhase.speechToText) {
          _pipeline.transitionTo(VoicePipelinePhase.sttFailed);
          _sttStage = VoiceStepStatus.error;
        } else if (_pipeline.phase == VoicePipelinePhase.validatingAudio) {
          _pipeline.transitionTo(VoicePipelinePhase.invalidAudio);
          _micStage = VoiceStepStatus.error;
        } else if (_pipeline.phase == VoicePipelinePhase.recording) {
          _pipeline.transitionTo(VoicePipelinePhase.recordingFailed);
          _micStage = VoiceStepStatus.error;
        } else if (_pipeline.phase == VoicePipelinePhase.translation) {
          _pipeline.transitionTo(VoicePipelinePhase.unknownError);
          _translationStage = VoiceStepStatus.error;
        } else if (_pipeline.phase == VoicePipelinePhase.textToSpeech) {
          _pipeline.transitionTo(VoicePipelinePhase.ttsUnavailable);
          _ttsStage = VoiceStepStatus.unavailable;
        } else if (_pipeline.phase == VoicePipelinePhase.requestingPermission) {
          _pipeline.transitionTo(VoicePipelinePhase.recordingFailed);
        }
        if (_micStage == VoiceStepStatus.running) {
          _micStage = VoiceStepStatus.error;
        }
        if (_sttStage == VoiceStepStatus.running) {
          _sttStage = VoiceStepStatus.error;
        }
        if (_translationStage == VoiceStepStatus.running) {
          _translationStage = VoiceStepStatus.error;
        }
        _completeStage = VoiceStepStatus.error;
        _mainStatus = 'Voice translation could not be completed';
        _error = _friendly(error);
      });
    }
  }

  String _friendly(Object error) {
    final message = error
        .toString()
        .replaceFirst('Bad state: ', '')
        .replaceFirst('Exception: ', '');
    return message.length > 240 ? '${message.substring(0, 237)}…' : message;
  }

  @override
  void dispose() {
    _recordTimer?.cancel();
    if (_recording) _speech.stopRecording();
    _speech.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final elapsed = _recordWatch?.elapsed ?? Duration.zero;
    return Scaffold(
      appBar: AppBar(title: const Text('Voice Translation')),
      body: SafeArea(
        child: LayoutBuilder(builder: (context, constraints) {
          final padding = constraints.maxWidth < 420 ? 16.0 : 24.0;
          return ListView(
            padding: EdgeInsets.all(padding),
            children: [
              Text('Hindi → Mundari offline voice pipeline',
                  style: theme.textTheme.titleMedium),
              const SizedBox(height: 16),
              _infoCard(
                  context,
                  'OFFLINE VOICE MODE',
                  'Speech processing is designed to run locally on the device.',
                  Icons.offline_bolt),
              const SizedBox(height: 16),
              _sectionTitle(context, 'Pipeline Status'),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.route),
                  title: const Text('Current pipeline state'),
                  subtitle: Text(_phaseLabel(_pipeline.phase)),
                ),
              ),
              Card(
                  child: Column(children: [
                _stageTile(
                  'Microphone',
                  _micStage,
                  detail: _testModeActive ? 'Bypassed — Test Mode' : null,
                ),
                _stageTile('Hindi Speech-to-Text', _sttStage),
                _stageTile('Hindi → Mundari Translation', _translationStage),
                _stageTile('Mundari Text-to-Speech', _ttsStage,
                    detail: _ttsAvailable
                        ? 'Installed non-network Mundari voice detected; playback has not run yet.'
                        : "Mundari voice output is not available on this device's current TTS engine."),
                _stageTile('Complete Voice Translation', _completeStage),
              ])),
              const SizedBox(height: 12),
              Center(
                  child: FilledButton.icon(
                onPressed: _processing
                    ? null
                    : (_recording ? _stopAndProcess : _startRecording),
                icon: Icon(_processing
                    ? Icons.hourglass_top
                    : _recording
                        ? Icons.stop
                        : Icons.mic),
                label: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Text(_processing
                        ? 'Processing offline…'
                        : _recording
                            ? 'Stop Recording'
                            : 'Start Recording')),
              )),
              const SizedBox(height: 20),
              _offlineTestCard(context),
              const SizedBox(height: 8),
              Center(
                  child: Text(
                      _recording
                          ? 'Listening…  ${_formatDuration(elapsed)}'
                          : _mainStatus,
                      textAlign: TextAlign.center)),
              if (_recording)
                const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Center(child: Text('Recording limit: 60 seconds'))),
              if (_error != null) ...[
                const SizedBox(height: 12),
                _messageCard(context, _error!, Icons.info_outline),
              ],
              if (_audio != null) ...[
                const SizedBox(height: 12),
                _messageCard(
                    context,
                    _audio!.hasUsableSignal
                        ? 'Audio captured and validated: ${_audio!.durationSeconds.toStringAsFixed(2)} s, ${_audio!.sampleRate} Hz, ${_audio!.channels} channel, 16-bit PCM, RMS ${_audio!.rmsAmplitude.toStringAsFixed(4)}, peak ${_audio!.peakAmplitude.toStringAsFixed(4)}.'
                        : (_audio!.error ?? 'Audio validation did not pass.'),
                    Icons.graphic_eq),
              ],
              const SizedBox(height: 20),
              _sectionTitle(context, 'Hindi Speech / Recognized Text'),
              _resultCard(
                  context,
                  _recognized ??
                      'Recognized Hindi speech will appear here after actual audio passes validation and offline STT.'),
              const SizedBox(height: 14),
              _sectionTitle(context, 'Mundari Translation'),
              _resultCard(
                  context,
                  _mundari ??
                      'Exact dataset translation will appear here when available.'),
              const SizedBox(height: 20),
              _sectionTitle(context, 'Performance'),
              Card(
                  child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _timing('Recording duration', _recordDuration,
                                suffix: 'speaking time'),
                            _timing('STT processing', _sttTime),
                            _timing('Translation lookup', _translationTime),
                            _timing('TTS start / playback', _ttsTime,
                                notMeasured: _ttsTime == null),
                            _timing('Total processing', _totalTime),
                            const Divider(),
                            const Text('Target: < 3 seconds'),
                            const Text(
                                'Status: Not validated on target hardware'),
                          ]))),
              const SizedBox(height: 12),
              _messageCard(
                  context,
                  'TTS is used only when an installed, non-network Mundari (unr) voice is detected. No Hindi or English fallback is used.',
                  Icons.volume_up_outlined),
              const SizedBox(height: 12),
              _sectionTitle(context, 'Developer Diagnostics'),
              Card(
                child: ExpansionTile(
                  leading: const Icon(Icons.developer_mode),
                  title: const Text('Local pipeline diagnostics'),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  children: [
                    _diagnostic('Pipeline state', _phaseLabel(_pipeline.phase)),
                    _diagnostic(
                        'Microphone permission',
                        _permissionGranted == null
                            ? 'Not requested in this session'
                            : _permissionGranted!
                                ? 'Granted'
                                : 'Denied'),
                    _diagnostic('ASR model loaded',
                        _speech.isRecognizerReady ? 'Yes' : 'No'),
                    _diagnostic('Translation dataset loaded',
                        _translation.isLoaded ? 'Yes' : 'No'),
                    _diagnostic(
                        'TTS capability',
                        !_ttsChecked
                            ? 'Checking'
                            : _ttsAvailable
                                ? 'Offline Mundari voice detected'
                                : 'Unavailable'),
                    _diagnostic(
                        'Last recording duration',
                        _audio == null
                            ? _durationText(_recordDuration)
                            : '${_audio!.durationSeconds.toStringAsFixed(2)} s'),
                    _diagnostic(
                        'Audio RMS',
                        _audio?.rmsAmplitude.toStringAsFixed(6) ??
                            'Not measured'),
                    _diagnostic(
                        'Audio peak',
                        _audio?.peakAmplitude.toStringAsFixed(6) ??
                            'Not measured'),
                    _diagnostic(
                        'Audio validation', _durationText(_validationTime)),
                    _diagnostic('STT', _durationText(_sttTime)),
                    _diagnostic(
                        'Translation lookup', _durationText(_translationTime)),
                    _diagnostic(
                        'TTS start / playback', _durationText(_ttsTime)),
                    _diagnostic('Total processing', _durationText(_totalTime)),
                    const Divider(),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text('Real Device Testing',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Requires a physical Android device, microphone permission, spoken Hindi, bundled offline Hindi ASR and Mundari dataset. Check device Mundari TTS availability. Target-hardware validation is still pending.',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _offlineTestCard(BuildContext context) {
    final result = _offlineTestResult;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Offline Pipeline Test',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
                'Tests Hindi speech recognition → Hindi→Mundari translation → Mundari voice output without using the microphone.'),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text('TEST MODE — MICROPHONE BYPASSED',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed:
                    _processing || _recording ? null : _runOfflinePipelineTest,
                icon: const Icon(Icons.science_outlined),
                label: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Text('Run Offline Pipeline Test'),
                ),
              ),
            ),
            const Text(
                'Use Start Recording for physical-device microphone testing.'),
            const SizedBox(height: 4),
            const Text(
                'Use Offline Pipeline Test to validate processing without microphone input.'),
            if (result != null) ...[
              const Divider(height: 24),
              const Text('Offline Pipeline Test Result',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              _diagnostic('Microphone', 'BYPASSED — Test Mode'),
              _diagnostic(
                  'Sample',
                  result.sampleAsset == null
                      ? 'Not available'
                      : result.sampleAsset!.split('/').last),
              _diagnostic('Audio', _testAudioStatus(result.audio)),
              if (result.audio != null) ...[
                _diagnostic('Duration',
                    '${result.audio!.durationSeconds.toStringAsFixed(2)} s'),
                _diagnostic(
                    'RMS', result.audio!.rmsAmplitude.toStringAsFixed(6)),
                _diagnostic(
                    'Peak', result.audio!.peakAmplitude.toStringAsFixed(6)),
              ],
              _diagnostic('Hindi STT', _summaryStatus(result.sttStatus)),
              if (result.recognizedText != null)
                _resultCard(
                    context, 'Recognized Hindi: ${result.recognizedText}'),
              _diagnostic(
                  'Hindi → Mundari', _summaryStatus(result.translationStatus)),
              if (result.mundariText != null)
                _resultCard(context, 'Mundari: ${result.mundariText}'),
              _diagnostic('Mundari TTS', _summaryStatus(result.ttsStatus)),
              if (result.error != null)
                _messageCard(context, result.error!, Icons.info_outline),
              const SizedBox(height: 8),
              const Text('Test Pipeline Timing',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              _diagnostic(
                  'Audio validation', _durationText(result.validationTime)),
              _diagnostic('STT', _durationText(result.sttTime)),
              _diagnostic('Translation', _durationText(result.translationTime)),
              _diagnostic('TTS', _durationText(result.ttsTime)),
              _diagnostic(
                  'Total processing', '${result.totalTime.inMilliseconds} ms'),
              const Text('Microphone recording time is excluded in Test Mode.'),
              const _TargetValidationNote(),
            ],
          ],
        ),
      ),
    );
  }

  String _testAudioStatus(AudioInspection? audio) {
    if (audio == null || !audio.fileExists) return 'FAIL — sample missing';
    if (!audio.isValidWav) return 'FAIL — invalid';
    if (!audio.hasUsableSignal) return 'FAIL — silent';
    return 'PASS — valid signal';
  }

  String _summaryStatus(VoiceStepStatus status) => switch (status) {
        VoiceStepStatus.notStarted => 'Not Run',
        VoiceStepStatus.running => 'Running',
        VoiceStepStatus.success => 'PASS',
        VoiceStepStatus.error => 'FAIL',
        VoiceStepStatus.unavailable => 'UNAVAILABLE',
      };

  Widget _sectionTitle(BuildContext context, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold)),
      );

  Widget _infoCard(
          BuildContext context, String title, String body, IconData icon) =>
      Card(
        color: Theme.of(context).colorScheme.primaryContainer,
        child: ListTile(
            leading: Icon(icon),
            title: Text(title,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(body)),
      );

  Widget _messageCard(BuildContext context, String message, IconData icon) =>
      Card(
        child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon),
              const SizedBox(width: 12),
              Expanded(child: SelectableText(message)),
            ])),
      );

  Widget _resultCard(BuildContext context, String value) => Card(
        child: Padding(
            padding: const EdgeInsets.all(18),
            child: SelectableText(value,
                style: Theme.of(context)
                    .textTheme
                    .bodyLarge
                    ?.copyWith(height: 1.5))),
      );

  Widget _stageTile(String title, VoiceStepStatus stage, {String? detail}) =>
      ListTile(
        leading: Icon(_stageIcon(stage), color: _stageColor(context, stage)),
        title: Text(title),
        subtitle: detail == null ? null : Text(detail),
        trailing: Text(_stageLabel(stage),
            textAlign: TextAlign.end,
            style: const TextStyle(fontWeight: FontWeight.w600)),
      );

  Widget _timing(String label, Duration? value,
          {String? suffix, bool notMeasured = false}) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(children: [
          Expanded(child: Text(label)),
          Text(
              notMeasured
                  ? 'Not measured'
                  : value == null
                      ? '—'
                      : '${value.inMilliseconds} ms${suffix == null ? '' : ' ($suffix)'}',
              style: const TextStyle(fontWeight: FontWeight.w600))
        ]),
      );

  Widget _diagnostic(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: Text(label)),
          const SizedBox(width: 12),
          Flexible(child: Text(value, textAlign: TextAlign.end)),
        ]),
      );

  String _durationText(Duration? duration) =>
      duration == null ? 'Not measured' : '${duration.inMilliseconds} ms';

  String _phaseLabel(VoicePipelinePhase phase) => switch (phase) {
        VoicePipelinePhase.idle => 'Idle',
        VoicePipelinePhase.requestingPermission =>
          'Requesting microphone permission',
        VoicePipelinePhase.recording => 'Recording',
        VoicePipelinePhase.validatingAudio => 'Validating audio',
        VoicePipelinePhase.sampleUnavailable => 'No bundled speech sample',
        VoicePipelinePhase.speechToText => 'Speech-to-Text',
        VoicePipelinePhase.translation => 'Hindi → Mundari translation',
        VoicePipelinePhase.textToSpeech => 'Mundari Text-to-Speech',
        VoicePipelinePhase.completed => 'Completed',
        VoicePipelinePhase.permissionDenied => 'Permission denied',
        VoicePipelinePhase.recordingFailed => 'Recording failed',
        VoicePipelinePhase.silentAudio => 'Silent audio',
        VoicePipelinePhase.invalidAudio => 'Invalid audio',
        VoicePipelinePhase.sttFailed => 'Speech-to-Text failed',
        VoicePipelinePhase.translationNotFound => 'Translation not found',
        VoicePipelinePhase.ttsUnavailable => 'Mundari TTS unavailable',
        VoicePipelinePhase.unknownError => 'Unknown error',
      };

  String _formatDuration(Duration duration) =>
      '${duration.inMinutes.toString().padLeft(2, '0')}:${(duration.inSeconds % 60).toString().padLeft(2, '0')}';

  IconData _stageIcon(VoiceStepStatus stage) => switch (stage) {
        VoiceStepStatus.notStarted => Icons.radio_button_unchecked,
        VoiceStepStatus.running => Icons.hourglass_top,
        VoiceStepStatus.success => Icons.check_circle_outline,
        VoiceStepStatus.unavailable => Icons.remove_circle_outline,
        VoiceStepStatus.error => Icons.error_outline,
      };

  Color _stageColor(BuildContext context, VoiceStepStatus stage) =>
      switch (stage) {
        VoiceStepStatus.success => Colors.green.shade700,
        VoiceStepStatus.error => Theme.of(context).colorScheme.error,
        VoiceStepStatus.unavailable => Colors.orange.shade800,
        VoiceStepStatus.running => Colors.red.shade700,
        _ => Theme.of(context).colorScheme.primary,
      };

  String _stageLabel(VoiceStepStatus stage) => switch (stage) {
        VoiceStepStatus.notStarted => 'Not Started',
        VoiceStepStatus.running => 'Running',
        VoiceStepStatus.success => 'Success',
        VoiceStepStatus.unavailable => 'Unavailable',
        VoiceStepStatus.error => 'Error',
      };
}
