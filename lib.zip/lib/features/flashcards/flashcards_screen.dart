import 'dart:math';

import 'package:flutter/material.dart';
import '../../services/storage/storage_service.dart';

class _Flashcard {
  const _Flashcard({required this.id, required this.hindi, required this.mundari, required this.category});

  final int id;
  final String hindi;
  final String mundari;
  final String category;
}

// Offline starter vocabulary for practice. Items are not asserted to be
// verified against the translation dataset.
const List<_Flashcard> _starterCards = [
  _Flashcard(id: 1, hindi: 'नमस्ते', mundari: 'जोहार', category: 'Greetings'),
  _Flashcard(id: 2, hindi: 'धन्यवाद', mundari: 'सुकुरिया', category: 'Greetings'),
  _Flashcard(id: 3, hindi: 'माँ', mundari: 'आया', category: 'Family'),
  _Flashcard(id: 4, hindi: 'पिता', mundari: 'अपु', category: 'Family'),
  _Flashcard(id: 5, hindi: 'एक', mundari: 'मिया', category: 'Numbers'),
  _Flashcard(id: 6, hindi: 'दो', mundari: 'बारिया', category: 'Numbers'),
  _Flashcard(id: 7, hindi: 'कुत्ता', mundari: 'सेता', category: 'Animals'),
  _Flashcard(id: 8, hindi: 'गाय', mundari: 'उरि', category: 'Animals'),
  _Flashcard(id: 9, hindi: 'किताब', mundari: 'किताब', category: 'Classroom'),
  _Flashcard(id: 10, hindi: 'पानी', mundari: 'दा:', category: 'Classroom'),
  _Flashcard(id: 11, hindi: 'आना', mundari: 'हिजु', category: 'Daily Activities'),
  _Flashcard(id: 12, hindi: 'जाना', mundari: 'सेनो', category: 'Daily Activities'),
];

class FlashcardsScreen extends StatefulWidget {
  const FlashcardsScreen({super.key});

  @override
  State<FlashcardsScreen> createState() => _FlashcardsScreenState();
}

class _FlashcardsScreenState extends State<FlashcardsScreen> {
  late List<_Flashcard> _cards = List.of(_starterCards);
  final Set<int> _mastered = {};
  final Set<int> _needsPractice = {};
  int _index = 0;
  int _practiceAgainCount = 0;
  bool _showMundari = false;
  bool _complete = false;

  @override
  void initState() {
    super.initState();
    _recordPracticeStart();
  }

  Future<void> _recordPracticeStart() async {
    try {
      await StorageService.instance.addHistory(
        type: 'flashcards',
        title: 'Vocabulary practice started',
        metadata: '${_starterCards.length} offline starter cards',
      );
    } catch (_) {
      // Practice remains available if the local history database is unavailable.
    }
  }

  void _move(int delta) {
    setState(() {
      final nextIndex = _index + delta;
      if (nextIndex >= _cards.length) {
        _complete = true;
      } else if (nextIndex >= 0) {
        _index = nextIndex;
        _showMundari = false;
      }
    });
  }

  void _markMastered() {
    setState(() {
      final id = _cards[_index].id;
      _mastered.add(id);
      _needsPractice.remove(id);
    });
    _move(1);
  }

  void _markPracticeAgain() {
    setState(() {
      final id = _cards[_index].id;
      _needsPractice.add(id);
      _mastered.remove(id);
      _practiceAgainCount++;
    });
    _move(1);
  }

  void _shuffle() {
    final previousOrder = _cards.map((card) => card.id).join(',');
    var shuffled = List<_Flashcard>.of(_starterCards)..shuffle(Random());
    if (shuffled.length > 1 && shuffled.map((card) => card.id).join(',') == previousOrder) {
      shuffled = [...shuffled.skip(1), shuffled.first];
    }
    setState(() {
      _cards = shuffled;
      _index = 0;
      _showMundari = false;
      _complete = false;
      _mastered.clear();
      _needsPractice.clear();
      _practiceAgainCount = 0;
    });
  }

  void _restart() => setState(() {
        _index = 0;
        _showMundari = false;
        _complete = false;
        _mastered.clear();
        _needsPractice.clear();
        _practiceAgainCount = 0;
      });

  void _audioPlaceholder() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Offline audio will be added in the voice phase.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Flashcards', style: TextStyle(fontWeight: FontWeight.bold))),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: _complete ? _completionView() : _practiceView(),
          ),
        ),
      ),
    );
  }

  Widget _practiceView() {
    final card = _cards[_index];
    final progress = _mastered.length / _cards.length;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Practice Hindi and Mundari vocabulary',
            style: TextStyle(fontSize: 16, color: Color(0xFF64748B))),
        const SizedBox(height: 18),
        _languageModes(),
        const SizedBox(height: 14),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Text('Progress', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
              Text('Mastered: ${_mastered.length} / ${_cards.length}',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
            const SizedBox(height: 10),
            LinearProgressIndicator(value: progress, minHeight: 10,
                borderRadius: BorderRadius.circular(8)),
            const SizedBox(height: 8),
            Text('Practice again: $_practiceAgainCount',
                style: const TextStyle(fontSize: 13, color: Color(0xFF64748B))),
          ]),
        )),
        const SizedBox(height: 12),
        Row(children: [
          const Expanded(child: Text('Offline starter vocabulary',
              style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF475569)))),
          OutlinedButton.icon(onPressed: _shuffle, icon: const Icon(Icons.shuffle), label: const Text('Shuffle Cards')),
        ]),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(children: [
              Row(children: [
                Chip(label: Text(card.category), avatar: const Icon(Icons.category_outlined, size: 17)),
                const Spacer(),
                Text('Card ${_index + 1} of ${_cards.length}',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 22),
              const Text('Hindi', style: TextStyle(color: Color(0xFF2563EB), fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(card.hindi, textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold)),
              Align(alignment: Alignment.centerRight, child: IconButton.filledTonal(
                onPressed: _audioPlaceholder,
                tooltip: 'Hindi audio placeholder',
                icon: const Icon(Icons.volume_up_outlined),
                style: IconButton.styleFrom(minimumSize: const Size(52, 52)),
              )),
              AnimatedSize(
                duration: const Duration(milliseconds: 160),
                child: _showMundari
                    ? Column(children: [
                        const Divider(height: 20),
                        const Text('Mundari', style: TextStyle(color: Color(0xFF2563EB), fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(card.mundari, textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w600)),
                        Align(alignment: Alignment.centerRight, child: IconButton.filledTonal(
                          onPressed: _audioPlaceholder,
                          tooltip: 'Mundari audio placeholder',
                          icon: const Icon(Icons.volume_up_outlined),
                          style: IconButton.styleFrom(minimumSize: const Size(52, 52)),
                        )),
                      ])
                    : const SizedBox.shrink(),
              ),
              const SizedBox(height: 4),
              SizedBox(width: double.infinity, height: 52,
                child: OutlinedButton.icon(
                  onPressed: () => setState(() => _showMundari = !_showMundari),
                  icon: Icon(_showMundari ? Icons.visibility_off_outlined : Icons.translate),
                  label: Text(_showMundari ? 'Hide Mundari' : 'Show Mundari'),
                )),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            onPressed: _index > 0 ? () => _move(-1) : null,
            icon: const Icon(Icons.arrow_back), label: const Text('Previous'),
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          )),
          const SizedBox(width: 12),
          Expanded(child: FilledButton.icon(
            onPressed: () => _move(1), icon: const Icon(Icons.arrow_forward), label: const Text('Next →'),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          )),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton.tonal(
            onPressed: _markMastered,
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            child: const Text('Got it'),
          )),
          const SizedBox(width: 12),
          Expanded(child: OutlinedButton(
            onPressed: _markPracticeAgain,
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            child: const Text('Practice Again'),
          )),
        ]),
        const SizedBox(height: 12),
        const Text('Audio is a placeholder. Offline audio will be added in the voice phase.',
            textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF64748B), fontSize: 12)),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _languageModes() => Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Language mode', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            const _ModeChip(label: 'Hindi → Mundari', active: true),
            const _ModeChip(label: 'Hindi → Santhali · Coming Soon', active: false),
            const _ModeChip(label: 'Hindi → Ho · Coming Soon', active: false),
          ]),
        ]),
      ));

  Widget _completionView() => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.celebration_outlined, size: 72, color: Color(0xFF059669)),
          const SizedBox(height: 14),
          const Text('Practice Complete 🎉', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 22),
          Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
            _SummaryRow(label: 'Total cards', value: '${_cards.length}'),
            const SizedBox(height: 12),
            _SummaryRow(label: 'Mastered', value: '${_mastered.length}'),
            const SizedBox(height: 12),
            _SummaryRow(label: 'Needs practice', value: '${_cards.length - _mastered.length}'),
            const SizedBox(height: 12),
            _SummaryRow(label: 'Marked for another review', value: '${_needsPractice.length}'),
            const SizedBox(height: 12),
            _SummaryRow(label: 'Practice-again selections', value: '$_practiceAgainCount'),
            const SizedBox(height: 16),
            LinearProgressIndicator(value: _mastered.length / _cards.length, minHeight: 10),
          ]))),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: _restart, icon: const Icon(Icons.replay), label: const Text('Practice Again'),
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.arrow_back),
              label: const Text('Back to Flashcards'), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54))),
        ]),
      );
}

class _ModeChip extends StatelessWidget {
  const _ModeChip({required this.label, required this.active});
  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) => Chip(
        avatar: Icon(active ? Icons.check_circle : Icons.lock_outline, size: 17),
        label: Text(label),
        backgroundColor: active ? Theme.of(context).colorScheme.primaryContainer : const Color(0xFFF1F5F9),
        side: BorderSide.none,
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 7),
      );
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))],
      );
}
