import 'package:flutter/material.dart';
import '../translation/translation_screen.dart';
import '../voice_translation/voice_translation_screen.dart';
import '../worksheet/worksheet_screen.dart';
import '../lessons/lessons_screen.dart';
import '../flashcards/flashcards_screen.dart';
import '../teacher/teacher_screen.dart';
import '../student/student_screen.dart';
import '../history/history_screen.dart';
import '../settings/settings_screen.dart';
import '../benchmark/benchmark_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edumate',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Settings',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SettingsScreen(),
                ),
              );
            },
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Greeting
              const Text(
                'Namaste! 👋',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0F172A),
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                'Learn, translate and teach — offline.',
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xFF64748B),
                ),
              ),

              const SizedBox(height: 24),

              // Offline status
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFFECFDF5),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: const Color(0xFFA7F3D0),
                  ),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.cloud_off,
                      color: Color(0xFF059669),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Offline Mode',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF065F46),
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Core learning features work locally.',
                            style: TextStyle(
                              color: Color(0xFF047857),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              const Text(
                'What do you want to do?',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0F172A),
                ),
              ),

              const SizedBox(height: 16),

              // Translation
              _FeatureCard(
                icon: Icons.translate,
                title: 'Text Translation',
                subtitle: 'Hindi ↔ Mundari',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const TranslationScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Voice
              _FeatureCard(
                icon: Icons.mic,
                title: 'Voice Translation',
                subtitle: 'Speak Hindi and translate offline',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const VoiceTranslationScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // History
              _FeatureCard(
                icon: Icons.history,
                title: 'History',
                subtitle: 'Review recent offline learning activity',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const HistoryScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Benchmark
              _FeatureCard(
                icon: Icons.speed,
                title: 'Performance Benchmark',
                subtitle: 'Measure local offline translation lookup time',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const BenchmarkScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Worksheet
              _FeatureCard(
                icon: Icons.picture_as_pdf,
                title: 'Bilingual Worksheet',
                subtitle: 'Create Hindi + Mundari worksheets',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const WorksheetScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Learning
              _FeatureCard(
                icon: Icons.school,
                title: 'Learning',
                subtitle: 'Lessons and flashcards',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LessonsScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Flashcards
              _FeatureCard(
                icon: Icons.style_outlined,
                title: 'Flashcards',
                subtitle: 'Practice Hindi and Mundari vocabulary offline',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const FlashcardsScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Teacher Mode
              _FeatureCard(
                icon: Icons.co_present_outlined,
                title: 'Teacher Mode',
                subtitle: 'Tools for classroom teaching',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const TeacherScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // Student Mode
              _FeatureCard(
                icon: Icons.person_outline,
                title: 'Student Mode',
                subtitle: 'Learn, practice and track your progress',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const StudentScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 24),

              // Prototype status
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Prototype Status',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1E3A8A),
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Currently working offline: '
                      'Hindi ↔ Mundari dataset-based translation.',
                      style: TextStyle(
                        color: Color(0xFF1E40AF),
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFFE2E8F0),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  icon,
                  color: const Color(0xFF2563EB),
                  size: 26,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right,
                color: Color(0xFF94A3B8),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
