import 'package:flutter/material.dart';

import '../../services/storage/storage_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _storage = StorageService.instance;
  late Future<List<HistoryItem>> _historyFuture;
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    _historyFuture = _storage.getHistory();
  }

  void _reload() => setState(() => _historyFuture = _storage.getHistory());

  Future<void> _clearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear History?'),
        content: const Text('This will permanently remove locally stored activity from this device.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear History')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await _storage.clearHistory();
      if (mounted) {
        _reload();
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Local history cleared.')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not clear history.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('History', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            TextButton.icon(
              onPressed: _clearHistory,
              icon: const Icon(Icons.delete_outline),
              label: const Text('Clear History'),
            ),
            const SizedBox(width: 8),
          ],
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 960),
              child: FutureBuilder<List<HistoryItem>>(
                future: _historyFuture,
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return _errorState();
                  }
                  if (snapshot.connectionState != ConnectionState.done) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final entries = snapshot.data ?? const <HistoryItem>[];
                  final visible = _filter == 'all'
                      ? entries
                      : entries.where((item) => item.type == _filter).toList(growable: false);
                  return RefreshIndicator(
                    onRefresh: () async => _reload(),
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.all(20),
                      children: [
                        _summaryCard(context),
                        const SizedBox(height: 18),
                        Row(children: [
                          const Expanded(child: Text('Activity', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
                          const SizedBox(width: 12),
                          _filterControl(),
                        ]),
                        const SizedBox(height: 10),
                        if (visible.isEmpty)
                          _emptyState(isFiltered: entries.isNotEmpty)
                        else
                          ...visible.map((item) => Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: _historyCard(item),
                              )),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      );

  Widget _summaryCard(BuildContext context) => Card(
        color: const Color(0xFFEFF6FF),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 48, height: 48,
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.history, color: Color(0xFF2563EB))),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('Recent Activity', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                Icon(Icons.cloud_off, size: 18, color: Color(0xFF059669)),
                SizedBox(width: 5),
                Text('Offline', style: TextStyle(color: Color(0xFF047857), fontWeight: FontWeight.w600)),
              ]),
              SizedBox(height: 6),
              Text('Your recent learning and translation activity is stored locally on this device.',
                  style: TextStyle(color: Color(0xFF475569), height: 1.4)),
            ])),
          ]),
        ),
      );

  Widget _filterControl() => DropdownButton<String>(
        value: _filter,
        underline: const SizedBox.shrink(),
        borderRadius: BorderRadius.circular(12),
        onChanged: (value) {
          if (value != null) setState(() => _filter = value);
        },
        items: const [
          DropdownMenuItem(value: 'all', child: Text('All')),
          DropdownMenuItem(value: 'translation', child: Text('Translation')),
          DropdownMenuItem(value: 'voice_translation', child: Text('Voice')),
          DropdownMenuItem(value: 'worksheet', child: Text('Worksheet')),
          DropdownMenuItem(value: 'learning', child: Text('Learning')),
          DropdownMenuItem(value: 'flashcards', child: Text('Flashcards')),
        ],
      );

  Widget _historyCard(HistoryItem item) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _showDetails(item),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(width: 44, height: 44,
                decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(13)),
                child: Icon(_iconFor(item.type), color: Theme.of(context).colorScheme.primary)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(_labelFor(item.type), style: const TextStyle(fontWeight: FontWeight.bold))),
                  Text(_formatDate(item.createdAt), style: const TextStyle(fontSize: 12, color: Color(0xFF64748B))),
                ]),
                const SizedBox(height: 3),
                Text(item.title, style: const TextStyle(color: Color(0xFF334155))),
                if (item.sourceText?.isNotEmpty == true) ...[
                  const SizedBox(height: 8),
                  Text(item.sourceText!, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xFF475569))),
                ],
                if (item.resultText?.isNotEmpty == true) ...[
                  const SizedBox(height: 3),
                  Text(item.resultText!, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xFF2563EB))),
                ],
              ])),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right, color: Color(0xFF94A3B8)),
            ]),
          ),
        ),
      );

  void _showDetails(HistoryItem item) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_labelFor(item.type)),
        content: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          _detailField('Activity', item.title),
          _detailField('Date and time', _formatDate(item.createdAt, includeTime: true)),
          if (item.sourceText?.isNotEmpty == true) _detailField('Source', item.sourceText!),
          if (item.resultText?.isNotEmpty == true) _detailField('Result', item.resultText!),
          if (item.metadata?.isNotEmpty == true) _detailField('Details', item.metadata!),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      ),
    );
  }

  Widget _detailField(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF475569))),
          const SizedBox(height: 4),
          SelectableText(value),
        ]),
      );

  Widget _emptyState({required bool isFiltered}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 48, horizontal: 16),
        child: Column(children: [
          Icon(isFiltered ? Icons.filter_alt_off : Icons.history_toggle_off,
              size: 58, color: const Color(0xFF94A3B8)),
          const SizedBox(height: 12),
          Text(isFiltered ? 'No matching activity' : 'No activity yet',
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          Text(isFiltered ? 'Try another filter.' : 'Your recent activity will appear here.',
              textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF64748B))),
        ]),
      );

  Widget _errorState() => Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.storage_outlined, size: 48, color: Color(0xFF64748B)),
          const SizedBox(height: 12),
          const Text('Could not load local history.', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: _reload, icon: const Icon(Icons.refresh), label: const Text('Try again')),
        ]),
      ));

  IconData _iconFor(String type) => switch (type) {
        'translation' => Icons.translate,
        'voice_translation' => Icons.mic,
        'worksheet' => Icons.picture_as_pdf_outlined,
        'learning' => Icons.school_outlined,
        'flashcards' => Icons.style_outlined,
        _ => Icons.history,
      };

  String _labelFor(String type) => switch (type) {
        'translation' => 'Text Translation',
        'voice_translation' => 'Voice Translation',
        'worksheet' => 'Worksheet',
        'learning' => 'Learning',
        'flashcards' => 'Flashcards',
        _ => 'Activity',
      };

  String _formatDate(DateTime date, {bool includeTime = false}) {
    final local = date.toLocal();
    final datePart = '${local.day.toString().padLeft(2, '0')}/'
        '${local.month.toString().padLeft(2, '0')}/${local.year}';
    if (!includeTime) return datePart;
    final hour = local.hour % 12 == 0 ? 12 : local.hour % 12;
    final minute = local.minute.toString().padLeft(2, '0');
    final period = local.hour >= 12 ? 'PM' : 'AM';
    return '$datePart · $hour:$minute $period';
  }
}
