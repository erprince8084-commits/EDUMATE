import 'package:flutter/material.dart';

import '../flashcards/flashcards_screen.dart';
import '../lessons/lessons_screen.dart';
import '../translation/translation_screen.dart';
import '../worksheet/worksheet_screen.dart';
import '../history/history_screen.dart';

class StudentScreen extends StatefulWidget {
  const StudentScreen({super.key});

  @override
  State<StudentScreen> createState() => _StudentScreenState();
}

class _StudentScreenState extends State<StudentScreen> {
  // Session-only counters. They reset when Student Mode is closed because the
  // current app has no local progress persistence or completion callbacks.
  int _practiceSessions = 0;

  static const _lessons = <_StudentLesson>[
    _StudentLesson('Basic Greetings', 'Practice friendly greetings.', Icons.waving_hand_outlined),
    _StudentLesson('Numbers', 'Learn a few everyday numbers.', Icons.calculate_outlined),
    _StudentLesson('Family', 'Words for people in a family.', Icons.family_restroom),
    _StudentLesson('Animals', 'Learn names of familiar animals.', Icons.pets_outlined),
    _StudentLesson('Classroom', 'Useful words for learning together.', Icons.menu_book_outlined),
    _StudentLesson('Daily Activities', 'Talk about simple daily actions.', Icons.wb_sunny_outlined),
  ];

  void _open(BuildContext context, Widget screen, {bool practice = false}) {
    if (practice) setState(() => _practiceSessions++);
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Student Mode', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [IconButton(
            tooltip: 'History',
            onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => const HistoryScreen(),
            )),
            icon: const Icon(Icons.history),
          )],
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1100),
              child: LayoutBuilder(builder: (context, constraints) {
                final twoColumns = constraints.maxWidth >= 720;
                return ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    const Text('Learn, practice and track your progress',
                        style: TextStyle(fontSize: 16, color: Color(0xFF64748B))),
                    const SizedBox(height: 18),
                    _offlineCard(context),
                    const SizedBox(height: 22),
                    _sectionTitle('Continue Learning'),
                    const SizedBox(height: 10),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _lessons.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: twoColumns ? 2 : 1,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        mainAxisExtent: 158,
                      ),
                      itemBuilder: (context, index) => _lessonCard(context, _lessons[index]),
                    ),
                    const SizedBox(height: 22),
                    _sectionTitle('Practice'),
                    const SizedBox(height: 10),
                    _responsiveGrid(twoColumns, [
                      _ActivityCard(icon: Icons.style_outlined, title: 'Flashcards',
                          description: 'Review Hindi and Mundari vocabulary.', action: 'Open Flashcards',
                          onPressed: () => _open(context, const FlashcardsScreen(), practice: true)),
                      _ActivityCard(icon: Icons.spellcheck, title: 'Vocabulary Practice',
                          description: 'Practice vocabulary with flashcards.', action: 'Start Practice',
                          onPressed: () => _open(context, const FlashcardsScreen(), practice: true)),
                    ]),
                    const SizedBox(height: 22),
                    _sectionTitle('Quick Activities'),
                    const SizedBox(height: 10),
                    _responsiveGrid(twoColumns, [
                      _ActivityCard(icon: Icons.translate, title: 'Translation Practice',
                          description: 'Translate Hindi and Mundari offline.', action: 'Translate',
                          onPressed: () => _open(context, const TranslationScreen())),
                      _ActivityCard(icon: Icons.picture_as_pdf, title: 'Worksheet Practice',
                          description: 'Create or review a bilingual worksheet.', action: 'Open Worksheet',
                          onPressed: () => _open(context, const WorksheetScreen())),
                      _ActivityCard(icon: Icons.school_outlined, title: 'Learning Lessons',
                          description: 'Continue with the existing lesson collection.', action: 'Open Lessons',
                          onPressed: () => _open(context, const LessonsScreen())),
                      _ActivityCard(icon: Icons.style_outlined, title: 'Flashcards',
                          description: 'Practice the offline vocabulary deck.', action: 'Open Flashcards',
                          onPressed: () => _open(context, const FlashcardsScreen(), practice: true)),
                    ]),
                    const SizedBox(height: 22),
                    _sectionTitle('Progress'),
                    const SizedBox(height: 10),
                    _progressSection(twoColumns),
                    const SizedBox(height: 6),
                    const Text(
                      'Progress is held in memory for this session. Lesson completion and mastered-card totals start at 0.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    ),
                    const SizedBox(height: 20),
                    _dailyPractice(context),
                    const SizedBox(height: 20),
                  ],
                );
              }),
            ),
          ),
        ),
      );

  Widget _sectionTitle(String title) => Text(title,
      style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold));

  Widget _offlineCard(BuildContext context) => Card(
        color: const Color(0xFFECFDF5),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [
              Icon(Icons.cloud_off, color: Color(0xFF059669)),
              SizedBox(width: 10),
              Expanded(child: Text('OFFLINE STUDENT MODE',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF065F46)))),
            ]),
            const SizedBox(height: 8),
            const Text('Learning activities can be used without an internet connection.',
                style: TextStyle(color: Color(0xFF047857))),
            const SizedBox(height: 12),
            Text('Currently available offline:',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('• Learning lessons\n• Flashcards\n• Hindi ↔ Mundari dataset translation\n• Bilingual worksheets',
                style: TextStyle(height: 1.45, color: Color(0xFF065F46))),
          ]),
        ),
      );

  Widget _lessonCard(BuildContext context, _StudentLesson lesson) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(width: 44, height: 44,
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(13)),
              child: Icon(lesson.icon, color: Theme.of(context).colorScheme.primary)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 3),
              Text(lesson.description, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xFF64748B))),
              const SizedBox(height: 9),
              const LinearProgressIndicator(value: 0, minHeight: 6),
            ])),
            const SizedBox(width: 10),
            FilledButton(onPressed: () => _open(context, const LessonsScreen()),
              style: FilledButton.styleFrom(minimumSize: const Size(92, 46)),
              child: const Text('Continue')),
          ]),
        ),
      );

  Widget _responsiveGrid(bool twoColumns, List<Widget> children) => GridView.count(
        crossAxisCount: twoColumns ? 2 : 1,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: twoColumns ? 2.05 : 2.8,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        children: children,
      );

  Widget _progressSection(bool twoColumns) => _responsiveGrid(twoColumns, [
        const _ProgressTile(icon: Icons.school_outlined, label: 'Lessons completed', value: '0'),
        const _ProgressTile(icon: Icons.check_circle_outline, label: 'Flashcards mastered', value: '0'),
        _ProgressTile(icon: Icons.replay, label: 'Practice sessions', value: '$_practiceSessions'),
        const _ProgressTile(icon: Icons.insights_outlined, label: 'Overall progress', value: '0%', progress: 0),
      ]);

  Widget _dailyPractice(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(children: [
            Container(width: 48, height: 48,
                decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(14)),
                child: Icon(Icons.today_outlined, color: Theme.of(context).colorScheme.primary)),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text("Today's Practice", style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text('5 vocabulary items', style: TextStyle(color: Color(0xFF64748B))),
            ])),
            FilledButton(onPressed: () => _open(context, const FlashcardsScreen(), practice: true),
                style: FilledButton.styleFrom(minimumSize: const Size(130, 48)),
                child: const Text('Start Practice')),
          ]),
        ),
      );
}

class _StudentLesson {
  const _StudentLesson(this.title, this.description, this.icon);
  final String title;
  final String description;
  final IconData icon;
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({required this.icon, required this.title, required this.description,
      required this.action, required this.onPressed});
  final IconData icon;
  final String title;
  final String description;
  final String action;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Icon(icon, size: 30, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 4),
              Text(description, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xFF64748B))),
            ])),
            const SizedBox(width: 8),
            FilledButton(onPressed: onPressed,
              style: FilledButton.styleFrom(minimumSize: const Size(116, 46)),
              child: Text(action, textAlign: TextAlign.center)),
          ]),
        ),
      );
}

class _ProgressTile extends StatelessWidget {
  const _ProgressTile({required this.icon, required this.label, required this.value, this.progress});
  final IconData icon;
  final String label;
  final String value;
  final double? progress;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(label, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xFF64748B))),
              const SizedBox(height: 4),
              Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19)),
              if (progress != null) ...[
                const SizedBox(height: 5),
                LinearProgressIndicator(value: progress, minHeight: 5),
              ],
            ])),
          ]),
        ),
      );
}
