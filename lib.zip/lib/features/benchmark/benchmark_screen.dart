import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/translation/translation_service.dart';

class _BenchmarkResults {
  const _BenchmarkResults({
    required this.firstLookup,
    required this.warmLookup,
    required this.hindiToMundari,
    this.reverseLookup,
    this.mundariToHindi,
  });

  final Duration firstLookup;
  final Duration warmLookup;
  final Duration? reverseLookup;
  final String? hindiToMundari;
  final String? mundariToHindi;
}

class BenchmarkScreen extends StatefulWidget {
  const BenchmarkScreen({super.key});

  @override
  State<BenchmarkScreen> createState() => _BenchmarkScreenState();
}

class _BenchmarkScreenState extends State<BenchmarkScreen> {
  static const _sentence = 'वे भी कमजोर पड़ रहे हैं';
  final _translationService = TranslationService();

  _BenchmarkResults? _results;
  bool _running = false;
  bool _checkingModel = true;
  bool _modelAvailable = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkModelAssets();
  }

  Future<void> _checkModelAssets() async {
    try {
      final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
      final assets = manifest.listAssets();
      final available = assets.contains('assets/models/hindi/model.int8.onnx') &&
          assets.contains('assets/models/hindi/tokens.txt');
      if (mounted) setState(() => _modelAvailable = available);
    } catch (_) {
      if (mounted) setState(() => _modelAvailable = false);
    } finally {
      if (mounted) setState(() => _checkingModel = false);
    }
  }

  Future<void> _runBenchmark() async {
    if (_running) return;
    setState(() {
      _running = true;
      _results = null;
      _error = null;
    });

    try {
      final firstWatch = Stopwatch()..start();
      final hindiToMundari = await _translationService.translateHindiToMundari(_sentence);
      firstWatch.stop();

      final warmWatch = Stopwatch()..start();
      await _translationService.translateHindiToMundari(_sentence);
      warmWatch.stop();

      Duration? reverseDuration;
      String? mundariToHindi;
      if (hindiToMundari != null) {
        final reverseWatch = Stopwatch()..start();
        mundariToHindi = await _translationService.translateMundariToHindi(hindiToMundari);
        reverseWatch.stop();
        reverseDuration = reverseWatch.elapsed;
      }

      if (!mounted) return;
      setState(() {
        _results = _BenchmarkResults(
          firstLookup: firstWatch.elapsed,
          warmLookup: warmWatch.elapsed,
          reverseLookup: reverseDuration,
          hindiToMundari: hindiToMundari,
          mundariToHindi: mundariToHindi,
        );
      });
    } catch (_) {
      if (mounted) setState(() => _error = 'Benchmark could not complete.');
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Performance Benchmark', style: TextStyle(fontWeight: FontWeight.bold))),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 900),
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  const Text("Measure Edumate's offline processing performance.",
                      style: TextStyle(fontSize: 16, color: Color(0xFF64748B))),
                  const SizedBox(height: 18),
                  _offlineCard(context),
                  const SizedBox(height: 18),
                  _sectionTitle('Text Translation'),
                  const SizedBox(height: 8),
                  _translationCard(),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 56,
                    child: FilledButton.icon(
                      onPressed: _running ? null : _runBenchmark,
                      icon: _running
                          ? const SizedBox(width: 20, height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.speed),
                      label: Text(_running ? 'Running benchmark…' : 'Run Benchmark'),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 10),
                    _messageCard(_error!, isError: true),
                  ],
                  const SizedBox(height: 18),
                  _latestResults(),
                  const SizedBox(height: 18),
                  _sectionTitle('Voice Translation Pipeline'),
                  const SizedBox(height: 8),
                  _voicePipeline(),
                  const SizedBox(height: 18),
                  _sectionTitle('Model Status'),
                  const SizedBox(height: 8),
                  _modelCard(),
                  const SizedBox(height: 18),
                  _sectionTitle('Device Information'),
                  const SizedBox(height: 8),
                  _deviceCard(),
                  const SizedBox(height: 18),
                  _interpretationCard(context),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      );

  Widget _sectionTitle(String title) => Text(title,
      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold));

  Widget _offlineCard(BuildContext context) => Card(
        color: const Color(0xFFECFDF5),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [
              Icon(Icons.cloud_off, color: Color(0xFF059669)),
              SizedBox(width: 10),
              Expanded(child: Text('OFFLINE BENCHMARK',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF065F46)))),
              Text('Local', style: TextStyle(color: Color(0xFF047857), fontWeight: FontWeight.w600)),
            ]),
            const SizedBox(height: 8),
            const Text('Running locally on this device', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('Benchmark results are measured locally and are not uploaded.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: const Color(0xFF475569))),
          ]),
        ),
      );

  Widget _translationCard() => Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.translate, color: Color(0xFF2563EB)),
            SizedBox(width: 10),
            Expanded(child: Text('Hindi → Mundari',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
          ]),
          const SizedBox(height: 12),
          const Text('Benchmark sentence', style: TextStyle(fontSize: 12, color: Color(0xFF64748B))),
          const SizedBox(height: 4),
          const SelectableText(_sentence, style: TextStyle(fontSize: 17)),
          const SizedBox(height: 8),
          const Text('Offline dataset-based exact lookup',
              style: TextStyle(fontSize: 12, color: Color(0xFF64748B))),
        ]),
      ));

  Widget _latestResults() => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Latest Results', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            if (_results == null && !_running && _error == null)
              const Text('Not run yet', style: TextStyle(color: Color(0xFF64748B)))
            else ...[
              _ResultRow(label: 'First lookup', value: _formatDuration(_results?.firstLookup)),
              _ResultRow(label: 'Warm lookup', value: _formatDuration(_results?.warmLookup)),
              _ResultRow(label: 'Reverse lookup', value: _formatDuration(_results?.reverseLookup)),
              const Divider(height: 22),
              const Text('Hindi → Mundari result', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              SelectableText(_results?.hindiToMundari ??
                  'Benchmark sentence not available in current dataset.'),
              if (_results?.mundariToHindi != null) ...[
                const SizedBox(height: 10),
                const Text('Mundari → Hindi result', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                SelectableText(_results!.mundariToHindi!),
              ],
            ],
            const Divider(height: 22),
            const _ResultRow(label: 'Voice pipeline', value: 'Not tested'),
          ]),
        ),
      );

  String _formatDuration(Duration? duration) {
    if (duration == null) return 'Not available';
    final milliseconds = duration.inMicroseconds / 1000;
    return '${milliseconds.toStringAsFixed(2)} ms';
  }

  Widget _voicePipeline() => Card(child: Column(children: [
        const _StatusRow(label: 'Microphone', status: 'Not tested'),
        const Divider(height: 1, indent: 16),
        const _StatusRow(label: 'Hindi Speech-to-Text', status: 'Not tested'),
        const Divider(height: 1, indent: 16),
        _StatusRow(label: 'Hindi → Mundari Translation',
            status: _results?.hindiToMundari != null ? 'Measured above' : 'Not tested'),
        const Divider(height: 1, indent: 16),
        const _StatusRow(label: 'Mundari Text-to-Speech', status: 'Not tested'),
        const Divider(height: 1, indent: 16),
        const _StatusRow(label: 'Total Voice Translation', status: 'Not tested'),
      ]));

  Widget _modelCard() => Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _StatusRow(
            label: 'Hindi STT Model',
            status: _checkingModel ? 'Checking…' : (_modelAvailable ? 'Available' : 'Not available'),
          ),
          const Divider(height: 20),
          const _StatusRow(label: 'Model type', status: 'Offline / ONNX'),
          if (!_checkingModel && !_modelAvailable) ...[
            const SizedBox(height: 8),
            const Text('Hindi STT model assets not found.',
                style: TextStyle(color: Color(0xFFB91C1C))),
          ],
          const SizedBox(height: 5),
          const Text('Asset presence only; model accuracy has not been measured.',
              style: TextStyle(fontSize: 12, color: Color(0xFF64748B))),
        ]),
      ));

  Widget _deviceCard() => Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          _ResultRow(label: 'Platform', value: _platformName),
          const _ResultRow(label: 'Architecture', value: 'Not reported by Flutter runtime'),
        ]),
      ));

  String get _platformName {
    if (kIsWeb) return 'Web';
    return switch (defaultTargetPlatform) {
      TargetPlatform.android => 'Android',
      TargetPlatform.iOS => 'iOS',
      TargetPlatform.macOS => 'macOS',
      TargetPlatform.windows => 'Windows',
      TargetPlatform.linux => 'Linux',
      TargetPlatform.fuchsia => 'Fuchsia',
    };
  }

  Widget _interpretationCard(BuildContext context) => Card(
        color: const Color(0xFFF1F5F9),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text("What do these numbers mean?", style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
              '• First lookup includes loading the translation dataset.\n'
              '• Warm lookup measures a local lookup after the dataset is loaded.\n'
              '• Voice timing will be measured only after the complete voice pipeline is functional.\n'
              '• Results depend on the device.',
              style: TextStyle(height: 1.45, color: Color(0xFF475569)),
            ),
          ]),
        ),
      );

  Widget _messageCard(String message, {bool isError = false}) => Card(
        color: isError ? const Color(0xFFFEF2F2) : null,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Text(message, style: TextStyle(color: isError ? const Color(0xFFB91C1C) : null)),
        ),
      );
}

class _ResultRow extends StatelessWidget {
  const _ResultRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: Text(label, style: const TextStyle(color: Color(0xFF475569)))),
          const SizedBox(width: 12),
          Flexible(child: Text(value, textAlign: TextAlign.end,
              style: const TextStyle(fontWeight: FontWeight.w600))),
        ]),
      );
}

class _StatusRow extends StatelessWidget {
  const _StatusRow({required this.label, required this.status});
  final String label;
  final String status;

  @override
  Widget build(BuildContext context) => ListTile(
        dense: true,
        title: Text(label),
        trailing: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 145),
          child: Text(status, textAlign: TextAlign.end,
              style: const TextStyle(color: Color(0xFF64748B), fontWeight: FontWeight.w500)),
        ),
      );
}
