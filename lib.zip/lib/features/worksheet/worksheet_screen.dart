import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../../services/translation/translation_service.dart';
import '../../services/worksheet/worksheet_service.dart';
import '../../services/storage/storage_service.dart';

class WorksheetScreen extends StatefulWidget {
  const WorksheetScreen({super.key});

  @override
  State<WorksheetScreen> createState() => _WorksheetScreenState();
}

class _WorksheetScreenState extends State<WorksheetScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _grade = TextEditingController();
  final _subject = TextEditingController();
  final _topic = TextEditingController();
  final _hindi = TextEditingController();
  final _mundari = TextEditingController();
  final _translation = TranslationService();
  final _worksheetService = WorksheetService();
  final List<_QuestionDraft> _questions = [_QuestionDraft()];
  int _questionCount = 1;
  bool _translating = false;
  bool _generating = false;
  String? _translationMessage;

  @override
  void dispose() {
    _title.dispose();
    _grade.dispose();
    _subject.dispose();
    _topic.dispose();
    _hindi.dispose();
    _mundari.dispose();
    for (final question in _questions) {
      question.dispose();
    }
    super.dispose();
  }

  Future<void> _translate() async {
    final input = _hindi.text.trim();
    if (input.isEmpty) {
      _message('Enter Hindi content before translating.');
      return;
    }
    setState(() {
      _translating = true;
      _translationMessage = null;
    });
    try {
      final result = await _translation.translateHindiToMundari(input);
      if (!mounted) return;
      setState(() {
        _mundari.text = result ?? '';
        _translationMessage = result == null
            ? 'Translation not available in the current offline dataset.'
            : 'Translated using the offline Hindi → Mundari dataset.';
      });
    } catch (_) {
      if (mounted) setState(() => _translationMessage = 'Could not load the offline translation dataset.');
    } finally {
      if (mounted) setState(() => _translating = false);
    }
  }

  Future<void> _generatePdf() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;
    if (_questions.isEmpty || _questions.every((q) => q.hindi.text.trim().isEmpty)) {
      _message('Add at least one Hindi question to continue.');
      return;
    }
    setState(() => _generating = true);
    try {
      final content = WorksheetContent(
        title: _title.text.trim(),
        grade: _grade.text.trim(),
        subject: _subject.text.trim(),
        topic: _topic.text.trim(),
        hindiContent: _hindi.text.trim(),
        mundariContent: _mundari.text.trim().isEmpty
            ? 'Translation not available in the current offline dataset.'
            : _mundari.text.trim(),
        questions: _questions
            .where((q) => q.hindi.text.trim().isNotEmpty)
            .map((q) => WorksheetQuestion(
                  hindi: q.hindi.text.trim(),
                  mundari: q.mundari.text.trim().isEmpty
                      ? 'Translation not available in the current offline dataset.'
                      : q.mundari.text.trim(),
                ))
            .toList(),
      );
      final bytes = await _worksheetService.generatePdf(content);
      try {
        await StorageService.instance.addHistory(
          type: 'worksheet',
          title: content.title,
          metadata: [
            if (content.topic.isNotEmpty) 'Lesson/topic: ${content.topic}',
            if (content.grade.isNotEmpty) 'Class: ${content.grade}',
            if (content.subject.isNotEmpty) 'Subject: ${content.subject}',
          ].join(' · '),
        );
      } catch (_) {
        // PDF creation and preview remain available if local history fails.
      }
      if (!mounted) return;
      setState(() => _generating = false);
      _message('Worksheet PDF generated successfully.');
      await Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => _PdfPreviewScreen(bytes: bytes, title: content.title),
      ));
    } catch (error) {
      if (mounted) _message('Unable to generate PDF: $error');
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  void _resizeQuestions(int count) {
    setState(() {
      while (_questions.length < count) {
        _questions.add(_QuestionDraft());
      }
      while (_questions.length > count) {
        _questions.removeLast().dispose();
      }
      _questionCount = count;
    });
  }

  Widget _field(String label, TextEditingController controller,
      {int lines = 1, bool required = false, String? hint}) {
    return TextFormField(
      controller: controller,
      onChanged: (_) => setState(() {}),
      minLines: lines == 1 ? 1 : lines,
      maxLines: lines,
      textInputAction: lines == 1 ? TextInputAction.next : TextInputAction.newline,
      decoration: InputDecoration(labelText: label, hintText: hint, alignLabelWithHint: lines > 1),
      validator: required
          ? (value) => value == null || value.trim().isEmpty ? '$label is required.' : null
          : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bilingual Worksheet', style: TextStyle(fontWeight: FontWeight.bold))),
      body: SafeArea(
        child: LayoutBuilder(builder: (context, constraints) {
          final maxWidth = constraints.maxWidth > 900 ? 860.0 : double.infinity;
          return Center(
            child: SizedBox(
              width: maxWidth,
              child: Form(
                key: _formKey,
                child: ListView(
                  keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                  padding: const EdgeInsets.all(20),
                  children: [
                    const Text('Create an offline Hindi + Mundari learning worksheet',
                        style: TextStyle(color: Color(0xFF64748B), fontSize: 16)),
                    const SizedBox(height: 20),
                    _card('Worksheet details', Icons.edit_note, [
                      _field('Worksheet title', _title, required: true),
                      const SizedBox(height: 12),
                      LayoutBuilder(builder: (context, c) => c.maxWidth > 520
                          ? Row(children: [
                              Expanded(child: _field('Class / Grade', _grade)),
                              const SizedBox(width: 12),
                              Expanded(child: _field('Subject', _subject)),
                            ])
                          : Column(children: [
                              _field('Class / Grade', _grade),
                              const SizedBox(height: 12),
                              _field('Subject', _subject),
                            ])),
                      const SizedBox(height: 12),
                      _field('Lesson / topic', _topic),
                    ]),
                    const SizedBox(height: 16),
                    _card('Bilingual lesson content', Icons.menu_book, [
                      _field('Hindi instructions / content', _hindi, lines: 4, required: true,
                          hint: 'हिंदी में निर्देश या पाठ लिखें'),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 52,
                        child: OutlinedButton.icon(
                          onPressed: _translating ? null : _translate,
                          icon: _translating
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.translate),
                          label: Text(_translating ? 'Translating offline…' : 'Translate to Mundari'),
                        ),
                      ),
                      if (_translationMessage != null) ...[
                        const SizedBox(height: 8),
                        Text(_translationMessage!, style: TextStyle(
                          color: _translationMessage!.startsWith('Translation not')
                              ? Theme.of(context).colorScheme.error
                              : Theme.of(context).colorScheme.primary,
                        )),
                      ],
                      const SizedBox(height: 12),
                      _field('Mundari translation', _mundari, lines: 4,
                          hint: 'Translation appears here; you can edit it'),
                    ]),
                    const SizedBox(height: 16),
                    _card('Questions', Icons.quiz_outlined, [
                      Row(children: [
                        const Expanded(child: Text('Number of questions', style: TextStyle(fontWeight: FontWeight.w600))),
                        IconButton(onPressed: _questionCount > 1 ? () => _resizeQuestions(_questionCount - 1) : null,
                            icon: const Icon(Icons.remove_circle_outline), tooltip: 'Remove a question'),
                        Text('$_questionCount', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        IconButton(onPressed: _questionCount < 20 ? () => _resizeQuestions(_questionCount + 1) : null,
                            icon: const Icon(Icons.add_circle_outline), tooltip: 'Add a question'),
                      ]),
                      ..._questions.indexed.map((entry) => _questionCard(entry.$1, entry.$2)),
                    ]),
                    const SizedBox(height: 16),
                    _previewCard(),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 56,
                      child: FilledButton.icon(
                        onPressed: _generating ? null : _generatePdf,
                        icon: _generating
                            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.picture_as_pdf),
                        label: Text(_generating ? 'Generating PDF…' : 'Generate PDF'),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _questionCard(int index, _QuestionDraft question) => Container(
        margin: const EdgeInsets.only(top: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Question ${index + 1}', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextField(controller: question.hindi, onChanged: (_) => setState(() {}), minLines: 2, maxLines: 3,
              decoration: const InputDecoration(labelText: 'Hindi question', hintText: 'हिंदी में प्रश्न लिखें')),
          const SizedBox(height: 10),
          TextField(controller: question.mundari, onChanged: (_) => setState(() {}), minLines: 2, maxLines: 3,
              decoration: const InputDecoration(labelText: 'Mundari translation')),
          Align(alignment: Alignment.centerRight, child: TextButton.icon(
            onPressed: () async {
              final text = question.hindi.text.trim();
              if (text.isEmpty) return _message('Enter a Hindi question before translating.');
              final result = await _translation.translateHindiToMundari(text);
              if (!mounted) return;
              setState(() => question.mundari.text = result ??
                  'Translation not available in the current offline dataset.');
            },
            icon: const Icon(Icons.translate), label: const Text('Translate question'),
          )),
        ]),
      );

  Widget _card(String title, IconData icon, List<Widget> children) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10),
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))]),
            const SizedBox(height: 16),
            ...children,
          ]),
        ),
      );

  Widget _previewCard() => _card('Worksheet preview', Icons.visibility_outlined, [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, border: Border.all(color: const Color(0xFFE2E8F0)),
              borderRadius: BorderRadius.circular(10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Center(child: Column(children: [
              Text('EDUMATE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
              Text('Bilingual Learning Worksheet', style: TextStyle(fontWeight: FontWeight.w600)),
            ])),
            const Divider(height: 24),
            Text(_title.text.isEmpty ? 'Worksheet title' : _title.text,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('Class: ${_grade.text}    Subject: ${_subject.text}'),
            Text('Lesson / Topic: ${_topic.text}'),
            const SizedBox(height: 12),
            const Text('Hindi section', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(_hindi.text.isEmpty ? 'Hindi instructions / content' : _hindi.text),
            const SizedBox(height: 8),
            const Text('Mundari section', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(_mundari.text.isEmpty ? 'Mundari translation' : _mundari.text),
            const SizedBox(height: 12),
            ..._questions.indexed.map((entry) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text('${entry.$1 + 1}. ${entry.$2.hindi.text.isEmpty ? 'Hindi question' : entry.$2.hindi.text}\n'
                  '   ${entry.$2.mundari.text.isEmpty ? 'Mundari translation' : entry.$2.mundari.text}'),
            )),
          ]),
        ),
      ]);
}

class _QuestionDraft {
  final hindi = TextEditingController();
  final mundari = TextEditingController();
  void dispose() {
    hindi.dispose();
    mundari.dispose();
  }
}

class _PdfPreviewScreen extends StatelessWidget {
  const _PdfPreviewScreen({required this.bytes, required this.title});
  final Uint8List bytes;
  final String title;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Worksheet PDF')),
        body: PdfPreview(
          build: (_) async => bytes,
          pdfFileName: '${title.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_')}.pdf',
          canChangeOrientation: false,
          canChangePageFormat: false,
          allowPrinting: true,
          allowSharing: true,
          pdfPreviewPageDecoration: const BoxDecoration(color: Color(0xFFE2E8F0)),
        ),
      );
}
