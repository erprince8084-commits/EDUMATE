import 'package:flutter/material.dart';
import '../../services/storage/storage_service.dart';

/// Locally bundled introductory examples. These examples are for practice and
/// are not asserted to be verified against Edumate's translation dataset.
class _LearningItem {
  const _LearningItem(this.hindi, this.mundari);

  final String hindi;
  final String mundari;
}

class _Lesson {
  const _Lesson({
    required this.title,
    required this.description,
    required this.icon,
    required this.items,
  });

  final String title;
  final String description;
  final IconData icon;
  final List<_LearningItem> items;
}

const _lessons = <_Lesson>[
  _Lesson(
    title: 'Basic Greetings',
    description: 'Practice friendly words for meeting people.',
    icon: Icons.waving_hand_outlined,
    items: [
      _LearningItem('नमस्ते', 'जोहार'),
      _LearningItem('आप कैसे हैं?', 'चेतना मिचि मेना?'),
      _LearningItem('धन्यवाद', 'सुकुरिया'),
    ],
  ),
  _Lesson(
    title: 'Numbers',
    description: 'Learn to recognize a few everyday numbers.',
    icon: Icons.calculate_outlined,
    items: [
      _LearningItem('एक', 'मिया'),
      _LearningItem('दो', 'बारिया'),
      _LearningItem('तीन', 'अपिया'),
      _LearningItem('चार', 'उपुनिया'),
    ],
  ),
  _Lesson(
    title: 'Family',
    description: 'Words for people in a family.',
    icon: Icons.family_restroom,
    items: [
      _LearningItem('माँ', 'आया'),
      _LearningItem('पिता', 'अपु'),
      _LearningItem('बच्चा', 'होन'),
    ],
  ),
  _Lesson(
    title: 'Animals',
    description: 'Explore names of familiar animals.',
    icon: Icons.pets_outlined,
    items: [
      _LearningItem('कुत्ता', 'सेता'),
      _LearningItem('गाय', 'उरि'),
      _LearningItem('बकरी', 'मेन्डी'),
    ],
  ),
  _Lesson(
    title: 'Classroom',
    description: 'Useful words for learning together.',
    icon: Icons.menu_book_outlined,
    items: [
      _LearningItem('किताब', 'किताब'),
      _LearningItem('पानी', 'दा:'),
      _LearningItem('घर', 'ओड़ा'),
    ],
  ),
  _Lesson(
    title: 'Daily Activities',
    description: 'Talk about simple daily actions.',
    icon: Icons.wb_sunny_outlined,
    items: [
      _LearningItem('आना', 'हिजु'),
      _LearningItem('जाना', 'सेनो'),
      _LearningItem('खाना', 'जोम'),
    ],
  ),
];

class LessonsScreen extends StatelessWidget {
  const LessonsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final columns = width >= 1050 ? 3 : (width >= 680 ? 2 : 1);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Learning', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1120),
            child: CustomScrollView(
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                  sliver: SliverToBoxAdapter(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Learn languages through simple lessons',
                            style: TextStyle(fontSize: 16, color: Color(0xFF64748B))),
                        const SizedBox(height: 20),
                        _languageSelector(context),
                        const SizedBox(height: 22),
                        const Text('Choose a lesson',
                            style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                      ],
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  sliver: SliverGrid.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      mainAxisExtent: 252,
                    ),
                    itemCount: _lessons.length,
                    itemBuilder: (context, index) => _LessonCard(lesson: _lessons[index]),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  sliver: SliverToBoxAdapter(
                    child: Text(
                      'These starter examples are bundled for offline practice and may not match the translation dataset.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFF64748B)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _languageSelector(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Learning language', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 10, children: [
              const _LanguageChip(label: 'Hindi → Mundari', active: true),
              const _LanguageChip(label: 'Hindi → Santhali', active: false),
              const _LanguageChip(label: 'Hindi → Ho', active: false),
            ]),
          ]),
        ),
      );
}

class _LanguageChip extends StatelessWidget {
  const _LanguageChip({required this.label, required this.active});
  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) => Chip(
        avatar: Icon(active ? Icons.check_circle : Icons.lock_outline, size: 18),
        label: Text(active ? label : '$label · Coming Soon'),
        backgroundColor: active ? Theme.of(context).colorScheme.primaryContainer : const Color(0xFFF1F5F9),
        side: BorderSide.none,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      );
}

class _LessonCard extends StatelessWidget {
  const _LessonCard({required this.lesson});
  final _Lesson lesson;

  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(lesson.icon, color: Theme.of(context).colorScheme.primary),
              ),
              const Spacer(),
              Text('${lesson.items.length} items', style: Theme.of(context).textTheme.labelLarge),
            ]),
            const SizedBox(height: 12),
            Text(lesson.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(lesson.description, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Color(0xFF64748B))),
            const Spacer(),
            const Text('Hindi → Mundari', style: TextStyle(fontSize: 13, color: Color(0xFF475569))),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: FilledButton(
                onPressed: () async {
                  try {
                    await StorageService.instance.addHistory(
                      type: 'learning',
                      title: lesson.title,
                      metadata: 'Lesson started',
                    );
                  } catch (_) {
                    // Starting a lesson should not depend on history storage.
                  }
                  if (!context.mounted) return;
                  Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => _LessonDetailScreen(lesson: lesson),
                  ));
                },
                child: const Text('Start Lesson'),
              ),
            ),
          ]),
        ),
      );
}

class _LessonDetailScreen extends StatefulWidget {
  const _LessonDetailScreen({required this.lesson});
  final _Lesson lesson;

  @override
  State<_LessonDetailScreen> createState() => _LessonDetailScreenState();
}

class _LessonDetailScreenState extends State<_LessonDetailScreen> {
  int _index = 0;
  bool _complete = false;

  Future<void> _next() async {
    if (_index == widget.lesson.items.length - 1) {
      try {
        await StorageService.instance.addHistory(
          type: 'learning',
          title: widget.lesson.title,
          metadata: 'Lesson completed · ${widget.lesson.items.length} items',
        );
      } catch (_) {
        // Lesson completion remains usable without a successful history write.
      }
      if (!mounted) return;
      setState(() => _complete = true);
    } else {
      setState(() => _index++);
    }
  }

  void _restart() => setState(() {
        _index = 0;
        _complete = false;
      });

  @override
  Widget build(BuildContext context) {
    final count = widget.lesson.items.length;
    final progress = _complete ? 1.0 : (_index + 1) / count;
    return Scaffold(
      appBar: AppBar(title: Text(widget.lesson.title)),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: _complete ? _completionView(count) : _itemView(count, progress),
            ),
          ),
        ),
      ),
    );
  }

  Widget _itemView(int count, double progress) {
    final item = widget.lesson.items[_index];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('Item ${_index + 1} of $count', style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      LinearProgressIndicator(value: progress, minHeight: 9, borderRadius: BorderRadius.circular(8)),
      const SizedBox(height: 22),
      Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('Hindi', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text(item.hindi, textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
              const SizedBox(height: 28),
              const Divider(),
              const SizedBox(height: 20),
              Text('Mundari', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text(item.mundari, textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w600)),
              const SizedBox(height: 24),
              IconButton.filledTonal(
                onPressed: null,
                tooltip: 'Audio playback coming in a future lesson update',
                icon: const Icon(Icons.volume_up_outlined),
                iconSize: 28,
                style: IconButton.styleFrom(minimumSize: const Size(56, 56)),
              ),
              const SizedBox(height: 6),
              const Text('Audio coming soon', style: TextStyle(color: Color(0xFF64748B))),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: OutlinedButton.icon(
          onPressed: _index > 0 ? () => setState(() => _index--) : null,
          icon: const Icon(Icons.arrow_back), label: const Text('Previous'),
          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54)),
        )),
        const SizedBox(width: 12),
        Expanded(child: FilledButton.icon(
          onPressed: _next,
          icon: Icon(_index == count - 1 ? Icons.done : Icons.arrow_forward),
          label: Text(_index == count - 1 ? 'Complete' : 'Next'),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
        )),
      ]),
    ]);
  }

  Widget _completionView(int count) => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.celebration_outlined, size: 72, color: Color(0xFF059669)),
          const SizedBox(height: 16),
          const Text('Lesson Complete 🎉', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          Card(child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              _CompletionRow(label: 'Items completed', value: '$count / $count'),
              const SizedBox(height: 12),
              const _CompletionRow(label: 'Progress', value: '100%'),
              const SizedBox(height: 16),
              const LinearProgressIndicator(value: 1, minHeight: 10),
            ]),
          )),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _restart,
            icon: const Icon(Icons.restart_alt),
            label: const Text('Restart Lesson'),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back),
            label: const Text('Back to Learning'),
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          ),
        ],
      );
}

class _CompletionRow extends StatelessWidget {
  const _CompletionRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))],
      );
}
