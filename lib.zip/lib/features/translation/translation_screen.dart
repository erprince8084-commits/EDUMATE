import 'package:flutter/material.dart';

import '../../services/translation/hindi_nlp_service.dart';
import '../../services/translation/translation_service.dart';
import '../../services/storage/storage_service.dart';

class TranslationScreen extends StatefulWidget {
  const TranslationScreen({super.key});

  @override
  State<TranslationScreen> createState() => _TranslationScreenState();
}

class _TranslationScreenState extends State<TranslationScreen> {
  final TranslationService _translationService = TranslationService();
  late final HindiNlpService _hindiNlpService =
      HindiNlpService(translationService: _translationService);
  final TextEditingController _inputController = TextEditingController();

  String _sourceLanguage = 'Hindi';
  String _targetLanguage = 'Mundari';

  String _result = '';
  String? _resultIndicator;
  bool _isTranslating = false;

  final List<String> _languages = [
    'Hindi',
    'English',
    'Mundari',
    'Santhali',
    'Ho',
    'Hinglish',
  ];

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  Future<void> _translate() async {
    FocusScope.of(context).unfocus();

    final input = _inputController.text.trim();
    final sourceLanguage = _sourceLanguage;
    final targetLanguage = _targetLanguage;

    if (input.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter some text first.'),
        ),
      );
      return;
    }

    setState(() {
      _isTranslating = true;
      _result = '';
      _resultIndicator = null;
    });

    String? translated;
    NlpTranslationResult? nlpResult;
    String? errorMessage;
    try {
      if (sourceLanguage == 'Hindi' && targetLanguage == 'Mundari') {
        nlpResult = await _hindiNlpService.translateHindiToMundari(input);
        translated = nlpResult.translatedText;
      } else if (sourceLanguage == 'Mundari' && targetLanguage == 'Hindi') {
        translated = await _translationService.translateMundariToHindi(input);
      }

      if (translated != null) {
        try {
          await StorageService.instance.addHistory(
            type: 'translation',
            title: '$sourceLanguage → $targetLanguage',
            sourceText: input,
            resultText: translated,
          );
        } catch (_) {
          // A history write failure must not interrupt a successful translation.
        }
      }
    } catch (_) {
      errorMessage = 'Offline translation could not be completed.';
    }

    if (!mounted) return;

    setState(() {
      _isTranslating = false;

      if (translated != null) {
        _result = translated;
        _resultIndicator = switch (nlpResult?.matchType) {
          NlpMatchType.exact => 'Offline dataset match',
          NlpMatchType.normalizedExact =>
            'Offline dataset match · punctuation/spacing normalized',
          NlpMatchType.similarity =>
            'Offline NLP match · ${(nlpResult!.score * 100).round()}% matching score',
          _ => 'Offline dataset match',
        };
      } else if (errorMessage != null) {
        _result = errorMessage;
        _resultIndicator = null;
      } else if ((_sourceLanguage == 'Hindi' && _targetLanguage == 'Mundari') ||
          (_sourceLanguage == 'Mundari' && _targetLanguage == 'Hindi')) {
        if (nlpResult?.isAmbiguous == true) {
          _result =
              'Multiple similar matches found. Please enter a more specific sentence.';
        } else if (_sourceLanguage == 'Hindi' && _targetLanguage == 'Mundari') {
          _result = 'No confident offline match found.';
        } else {
          _result =
              'No exact translation found in the current offline dataset.';
        }
        _resultIndicator = null;
      } else {
        _result = 'This language pair is coming soon. '
            'Currently available offline: Hindi ↔ Mundari.';
        _resultIndicator = null;
      }
    });
  }

  void _swapLanguages() {
    setState(() {
      final oldSource = _sourceLanguage;

      _sourceLanguage = _targetLanguage;
      _targetLanguage = oldSource;

      _result = '';
      _resultIndicator = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Text Translation',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Translate Offline',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                'Hindi ↔ Mundari',
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xFF64748B),
                ),
              ),

              const SizedBox(height: 24),

              // LANGUAGE SELECTORS
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: const Color(0xFFE2E8F0),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: _LanguageDropdown(
                        value: _sourceLanguage,
                        languages: _languages,
                        onChanged: (value) {
                          if (value == null) return;

                          setState(() {
                            _sourceLanguage = value;
                            _result = '';
                            _resultIndicator = null;
                          });
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed: _swapLanguages,
                      icon: const Icon(
                        Icons.swap_horiz,
                        size: 28,
                      ),
                      tooltip: 'Swap languages',
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _LanguageDropdown(
                        value: _targetLanguage,
                        languages: _languages,
                        onChanged: (value) {
                          if (value == null) return;

                          setState(() {
                            _targetLanguage = value;
                            _result = '';
                            _resultIndicator = null;
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              const Text(
                'Enter text',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              TextField(
                controller: _inputController,
                maxLines: 5,
                textInputAction: TextInputAction.newline,
                decoration: InputDecoration(
                  hintText: _sourceLanguage == 'Hindi'
                      ? 'हिंदी वाक्य यहाँ लिखें...'
                      : 'Enter your sentence here...',
                  alignLabelWithHint: true,
                  suffixIcon: IconButton(
                    onPressed: () {
                      _inputController.clear();

                      setState(() {
                        _result = '';
                        _resultIndicator = null;
                      });
                    },
                    icon: const Icon(Icons.clear),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isTranslating ? null : _translate,
                  icon: _isTranslating
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.translate),
                  label: Text(
                    _isTranslating ? 'Translating...' : 'Translate',
                  ),
                ),
              ),

              const SizedBox(height: 24),

              if (_result.isNotEmpty) ...[
                const Text(
                  'Translation',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFF6FF),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: const Color(0xFFBFDBFE),
                    ),
                  ),
                  child: Text(
                    _result,
                    style: const TextStyle(
                      fontSize: 18,
                      height: 1.5,
                    ),
                  ),
                ),
                if (_resultIndicator != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _resultIndicator!,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ],

              const SizedBox(height: 24),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFBEB),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: const Color(0xFFFDE68A),
                  ),
                ),
                child: const Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: Color(0xFFD97706),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Currently working offline: '
                        'Hindi ↔ Mundari dataset-based translation. '
                        'English, Santhali, Ho and Hinglish '
                        'support will be added in upcoming modules.',
                        style: TextStyle(
                          color: Color(0xFF92400E),
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LanguageDropdown extends StatelessWidget {
  final String value;
  final List<String> languages;
  final ValueChanged<String?> onChanged;

  const _LanguageDropdown({
    required this.value,
    required this.languages,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      isExpanded: true,
      initialValue: value,
      decoration: const InputDecoration(
        contentPadding: EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 4,
        ),
      ),
      items: languages.map(
        (language) {
          return DropdownMenuItem<String>(
            value: language,
            child: Text(
              language,
              overflow: TextOverflow.ellipsis,
            ),
          );
        },
      ).toList(),
      onChanged: onChanged,
    );
  }
}
