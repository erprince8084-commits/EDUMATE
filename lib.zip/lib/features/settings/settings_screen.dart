import 'package:flutter/material.dart';

import '../../services/storage/settings_service.dart';
import '../../services/storage/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settings = SettingsService();
  String _learningMode = SettingsService.defaultLearningMode;
  String _translationPair = SettingsService.defaultTranslationPair;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    try {
      final values = await Future.wait([
        _settings.getLearningMode(),
        _settings.getTranslationPair(),
      ]);
      if (!mounted) return;
      setState(() {
        _learningMode = values[0];
        _translationPair = values[1];
      });
    } catch (_) {
      // Keep sensible defaults available if local preferences cannot be read.
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _setLearningMode(String mode) async {
    final previous = _learningMode;
    setState(() => _learningMode = mode);
    try {
      await _settings.saveLearningMode(mode);
      if (mounted) _message('Learning mode preference saved.');
    } catch (_) {
      if (!mounted) return;
      setState(() => _learningMode = previous);
      _message('Could not save the preference on this device.');
    }
  }

  Future<void> _setTranslationPair(String pair) async {
    final previous = _translationPair;
    setState(() => _translationPair = pair);
    try {
      await _settings.saveTranslationPair(pair);
      if (mounted) _message('Translation pair preference saved.');
    } catch (_) {
      if (!mounted) return;
      setState(() => _translationPair = previous);
      _message('Could not save the preference on this device.');
    }
  }

  Future<void> _clearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear History?'),
        content: const Text('This will remove locally stored activity history from this device. Your settings will be kept.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear History')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await StorageService.instance.clearHistory();
      if (mounted) _message('History cleared.');
    } catch (_) {
      if (mounted) _message('Could not clear history on this device.');
    }
  }

  Future<void> _resetSettings() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset settings?'),
        content: const Text(
          'This will restore Edumate preferences to their default values. Your history, translation datasets, and offline models will not be deleted.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Reset')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await _settings.resetSettings();
      if (!mounted) return;
      setState(() {
        _learningMode = SettingsService.defaultLearningMode;
        _translationPair = SettingsService.defaultTranslationPair;
      });
      _message('Settings reset.');
    } catch (_) {
      if (mounted) _message('Could not reset settings on this device.');
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.bold))),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 920),
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  _appStatus(context),
                  const SizedBox(height: 20),
                  _sectionTitle('Language'),
                  const SizedBox(height: 8),
                  _languageCard(context),
                  const SizedBox(height: 20),
                  _sectionTitle('Learning Mode'),
                  const SizedBox(height: 8),
                  _learningModeCard(context),
                  const SizedBox(height: 20),
                  _sectionTitle('Voice & Audio'),
                  const SizedBox(height: 8),
                  _voiceCard(),
                  const SizedBox(height: 20),
                  _sectionTitle('Data & Storage'),
                  const SizedBox(height: 8),
                  _storageCard(),
                  const SizedBox(height: 20),
                  _sectionTitle('About Edumate'),
                  const SizedBox(height: 8),
                  _aboutCard(),
                  const SizedBox(height: 20),
                  _prototypeCard(context),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      );

  Widget _sectionTitle(String title) => Text(title,
      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold));

  Widget _appStatus(BuildContext context) => Card(
        color: const Color(0xFFECFDF5),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 48, height: 48,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                child: Icon(Icons.school, color: Theme.of(context).colorScheme.primary)),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Edumate', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                Text('Offline multilingual education assistant', style: TextStyle(color: Color(0xFF475569))),
              ])),
              const Icon(Icons.check_circle, color: Color(0xFF059669)),
            ]),
            const SizedBox(height: 14),
            const Text('Offline Mode', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF065F46))),
            const SizedBox(height: 4),
            const Text('Core prototype works locally on this device.', style: TextStyle(color: Color(0xFF047857))),
            const SizedBox(height: 6),
            const Text('Voice models and additional language packs are being integrated.',
                style: TextStyle(fontSize: 12, color: Color(0xFF475569))),
          ]),
        ),
      );

  Widget _languageCard(BuildContext context) => Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.language),
            title: Text('App Language'),
            subtitle: Text('English · Current interface language'),
            trailing: Icon(Icons.check_circle_outline),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 56, bottom: 10),
            child: Text('The app interface is currently available in English.',
                style: TextStyle(color: Color(0xFF64748B))),
          ),
          const Divider(),
          const Text('Translation Language Pair', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _translationPairSelector(),
          const SizedBox(height: 8),
          const Text(
            'Saved as your preferred pair. Translation screens retain their own language controls; currently available offline: Hindi ↔ Mundari.',
            style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
          ),
          const SizedBox(height: 8),
          const _ComingSoonLanguage(label: 'Hindi → Santhali'),
          const _ComingSoonLanguage(label: 'Hindi → Ho'),
          const _ComingSoonLanguage(label: 'Hindi → English'),
          const _ComingSoonLanguage(label: 'Hindi → Hinglish'),
        ]),
      ));

  Widget _learningModeCard(BuildContext context) => Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Choose the mode you usually use.', style: TextStyle(color: Color(0xFF64748B))),
          const SizedBox(height: 12),
          _learningModeSelector(),
          const SizedBox(height: 8),
          const Text('This preference is stored on this device. It does not automatically change your current screen.',
              style: TextStyle(fontSize: 12, color: Color(0xFF64748B))),
        ]),
      ));

  Widget _translationPairSelector() => LayoutBuilder(builder: (context, constraints) {
        if (constraints.maxWidth < 440) {
          return Wrap(spacing: 8, runSpacing: 4, children: [
            ChoiceChip(
              label: const Text('Hindi → Mundari'),
              selected: _translationPair == 'hindi_mundari',
              onSelected: _loading ? null : (selected) {
                if (selected) _setTranslationPair('hindi_mundari');
              },
            ),
            ChoiceChip(
              label: const Text('Mundari → Hindi'),
              selected: _translationPair == 'mundari_hindi',
              onSelected: _loading ? null : (selected) {
                if (selected) _setTranslationPair('mundari_hindi');
              },
            ),
          ]);
        }
        return SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'hindi_mundari', label: Text('Hindi → Mundari')),
            ButtonSegment(value: 'mundari_hindi', label: Text('Mundari → Hindi')),
          ],
          selected: {_translationPair},
          onSelectionChanged: _loading ? null : (value) => _setTranslationPair(value.first),
        );
      });

  Widget _learningModeSelector() => LayoutBuilder(builder: (context, constraints) {
        if (constraints.maxWidth < 440) {
          return Wrap(spacing: 8, runSpacing: 4, children: [
            ChoiceChip(
              avatar: const Icon(Icons.person_outline, size: 18),
              label: const Text('Student Mode'),
              selected: _learningMode == 'student',
              onSelected: _loading ? null : (selected) {
                if (selected) _setLearningMode('student');
              },
            ),
            ChoiceChip(
              avatar: const Icon(Icons.co_present_outlined, size: 18),
              label: const Text('Teacher Mode'),
              selected: _learningMode == 'teacher',
              onSelected: _loading ? null : (selected) {
                if (selected) _setLearningMode('teacher');
              },
            ),
          ]);
        }
        return SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'student', label: Text('Student Mode'), icon: Icon(Icons.person_outline)),
            ButtonSegment(value: 'teacher', label: Text('Teacher Mode'), icon: Icon(Icons.co_present_outlined)),
          ],
          selected: {_learningMode},
          onSelectionChanged: _loading ? null : (value) => _setLearningMode(value.first),
        );
      });

  Widget _voiceCard() => Card(child: Column(children: const [
        _StatusTile(icon: Icons.mic_none, title: 'Voice Input', status: 'Offline voice input — In development'),
        Divider(height: 1, indent: 56),
        _StatusTile(icon: Icons.record_voice_over_outlined, title: 'Text-to-Speech', status: 'Local TTS — In development'),
        Divider(height: 1, indent: 56),
        _StatusTile(icon: Icons.translate, title: 'Voice Translation', status: 'Coming Soon'),
        Divider(height: 1, indent: 56),
        _StatusTile(icon: Icons.speed, title: 'Speech rate', status: 'Coming Soon'),
        Divider(height: 1, indent: 56),
        _StatusTile(icon: Icons.play_circle_outline, title: 'Auto-play audio', status: 'Coming Soon'),
      ]));

  Widget _storageCard() => Card(child: Column(children: [
        const ListTile(
          leading: Icon(Icons.storage_outlined),
          title: Text('Local data'),
          subtitle: Text('History and preferences are stored on this device.'),
        ),
        const Divider(height: 1, indent: 56),
        ListTile(
          leading: const Icon(Icons.delete_outline),
          title: const Text('Clear History'),
          subtitle: const Text('Remove local activity history. Preferences will be kept.'),
          trailing: const Icon(Icons.chevron_right),
          onTap: _clearHistory,
        ),
        const Divider(height: 1, indent: 56),
        ListTile(
          leading: const Icon(Icons.restart_alt),
          title: const Text('Reset Settings'),
          subtitle: const Text('Restore preference defaults. History and offline files will be kept.'),
          trailing: const Icon(Icons.chevron_right),
          onTap: _resetSettings,
        ),
      ]));

  Widget _aboutCard() => Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Text('Edumate', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 3),
          Text('Offline multilingual education assistant'),
          SizedBox(height: 12),
          _AboutRow(label: 'Version', value: '1.0.0+1'),
          _AboutRow(label: 'Prototype language', value: 'Mundari'),
          _AboutRow(label: 'Current translation', value: 'Hindi ↔ Mundari dataset-based offline translation'),
          _AboutRow(label: 'Education focus', value: 'Mother Tongue-Based Multilingual Education'),
          SizedBox(height: 8),
          Text('Built for offline-first education workflows.', style: TextStyle(color: Color(0xFF475569))),
        ]),
      ));

  Widget _prototypeCard(BuildContext context) => Card(
        child: ExpansionTile(
          leading: Icon(Icons.info_outline, color: Theme.of(context).colorScheme.primary),
          title: const Text('Prototype Status', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: const Text('Working, in development, and coming soon'),
          childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          children: const [
            _StatusGroup(title: 'Working', items: [
              'Hindi ↔ Mundari text translation',
              'Bilingual worksheet generation',
              'Offline lessons',
              'Flashcards',
              'Teacher Mode',
              'Student Mode',
              'Local history',
            ]),
            SizedBox(height: 14),
            _StatusGroup(title: 'In Development', items: [
              'Offline voice input',
              'Voice translation',
              'Offline TTS validation',
              'Latency benchmark',
              'Additional tribal language packs',
            ]),
            SizedBox(height: 14),
            _StatusGroup(title: 'Coming Soon', items: [
              'Santhali translation',
              'Ho translation',
              'English/Hinglish datasets',
            ]),
          ],
        ),
      );
}

class _ComingSoonLanguage extends StatelessWidget {
  const _ComingSoonLanguage({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => ListTile(
        dense: true,
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.lock_outline, size: 18, color: Color(0xFF64748B)),
        title: Text(label),
        trailing: const Text('Coming Soon', style: TextStyle(fontSize: 12, color: Color(0xFF64748B))),
        enabled: false,
      );
}

class _StatusTile extends StatelessWidget {
  const _StatusTile({required this.icon, required this.title, required this.status});
  final IconData icon;
  final String title;
  final String status;

  @override
  Widget build(BuildContext context) => ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(status),
      );
}

class _AboutRow extends StatelessWidget {
  const _AboutRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 7),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 145, child: Text(label, style: const TextStyle(color: Color(0xFF64748B)))),
          Expanded(child: Text(value)),
        ]),
      );
}

class _StatusGroup extends StatelessWidget {
  const _StatusGroup({required this.title, required this.items});
  final String title;
  final List<String> items;

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        ...items.map((item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('•  '),
                Expanded(child: Text(item)),
              ]),
            )),
      ]);
}
