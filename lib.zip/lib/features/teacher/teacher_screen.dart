import 'package:flutter/material.dart';

import '../../services/translation/translation_service.dart';
import '../flashcards/flashcards_screen.dart';
import '../lessons/lessons_screen.dart';
import '../worksheet/worksheet_screen.dart';
import '../history/history_screen.dart';

class TeacherScreen extends StatelessWidget {
  const TeacherScreen({super.key});

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => screen,
      ),
    );
  }

  Future<void> _showQuickTranslation(BuildContext context) async {
    await showDialog<void>(
      context: context,
      builder: (_) => const _QuickTranslateDialog(),
    );
  }

  Future<void> _showLessonPlanner(BuildContext context) async {
    await showDialog<void>(
      context: context,
      builder: (_) => const _LessonPlannerDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Teacher Mode',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            tooltip: 'History',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const HistoryScreen(),
                ),
              );
            },
            icon: const Icon(Icons.history),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1050),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final columns = constraints.maxWidth > 700 ? 2 : 1;

                return ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    const Text(
                      'Tools for classroom teaching',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFF64748B),
                      ),
                    ),
                    const SizedBox(height: 18),
                    _offlineStatus(context),
                    const SizedBox(height: 20),
                    const Text(
                      'Quick Actions',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        _QuickAction(
                          label: 'Translate',
                          icon: Icons.translate,
                          onPressed: () => _showQuickTranslation(context),
                        ),
                        _QuickAction(
                          label: 'Worksheet',
                          icon: Icons.picture_as_pdf,
                          onPressed: () => _open(
                            context,
                            const WorksheetScreen(),
                          ),
                        ),
                        _QuickAction(
                          label: 'Lesson',
                          icon: Icons.edit_note,
                          onPressed: () => _showLessonPlanner(context),
                        ),
                        _QuickAction(
                          label: 'Flashcards',
                          icon: Icons.style_outlined,
                          onPressed: () => _open(
                            context,
                            const FlashcardsScreen(),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'Teaching tools',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    GridView.builder(
                      itemCount: 4,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: columns,
                        crossAxisSpacing: 14,
                        mainAxisSpacing: 14,

                        // FIX:
                        // Give every card enough vertical space.
                        mainAxisExtent: columns == 1 ? 285 : 250,
                      ),
                      itemBuilder: (context, index) {
                        switch (index) {
                          case 0:
                            return _ToolCard(
                              icon: Icons.edit_note,
                              title: 'Create Lesson',
                              description:
                                  'Plan a Hindi lesson with an offline Mundari translation.',
                              button: 'Plan a Lesson',
                              onPressed: () => _showLessonPlanner(context),
                            );

                          case 1:
                            return _ToolCard(
                              icon: Icons.picture_as_pdf,
                              title: 'Create Worksheet',
                              description:
                                  'Prepare printable Hindi and Mundari practice sheets.',
                              button: 'Open Worksheet Generator',
                              onPressed: () => _open(
                                context,
                                const WorksheetScreen(),
                              ),
                            );

                          case 2:
                            return _ToolCard(
                              icon: Icons.translate,
                              title: 'Translate Content',
                              description:
                                  'Look up Hindi text in the offline Mundari dataset.',
                              button: 'Translate Content',
                              onPressed: () => _showQuickTranslation(context),
                            );

                          case 3:
                            return _ClassroomActivities(
                              onLessons: () => _open(
                                context,
                                const LessonsScreen(),
                              ),
                              onFlashcards: () => _open(
                                context,
                                const FlashcardsScreen(),
                              ),
                            );

                          default:
                            return const SizedBox.shrink();
                        }
                      },
                    ),
                    const SizedBox(height: 20),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _offlineStatus(BuildContext context) {
    return Card(
      color: const Color(0xFFECFDF5),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(
                  Icons.cloud_off,
                  color: Color(0xFF059669),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'OFFLINE TEACHER MODE',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF065F46),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Core teaching tools are available without internet.',
              style: TextStyle(
                color: Color(0xFF047857),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Currently available offline:\n'
              'Hindi ↔ Mundari dataset translation, learning content, '
              'flashcards, and worksheet generation.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    height: 1.4,
                    color: const Color(0xFF065F46),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({
    required this.label,
    required this.icon,
    required this.onPressed,
  });

  final String label;
  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return FilledButton.tonalIcon(
      onPressed: onPressed,
      icon: Icon(icon),
      label: Text(label),
      style: FilledButton.styleFrom(
        minimumSize: const Size(130, 52),
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  const _ToolCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.button,
    required this.onPressed,
  });

  final IconData icon;
  final String title;
  final String description;
  final String button;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  icon,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Expanded(
              child: Text(
                description,
                style: const TextStyle(
                  color: Color(0xFF64748B),
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: FilledButton(
                onPressed: onPressed,
                child: Text(button),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ClassroomActivities extends StatelessWidget {
  const _ClassroomActivities({
    required this.onLessons,
    required this.onFlashcards,
  });

  final VoidCallback onLessons;
  final VoidCallback onFlashcards;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.groups_outlined,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Classroom Activities',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Run an existing offline activity with your class.',
              style: TextStyle(
                color: Color(0xFF64748B),
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 42,
              child: OutlinedButton.icon(
                onPressed: onFlashcards,
                icon: const Icon(Icons.style_outlined),
                label: const Text('Flashcards'),
              ),
            ),
            const SizedBox(height: 6),
            SizedBox(
              width: double.infinity,
              height: 42,
              child: OutlinedButton.icon(
                onPressed: onLessons,
                icon: const Icon(Icons.school_outlined),
                label: const Text('Learning Lessons'),
              ),
            ),
            const SizedBox(height: 6),
            SizedBox(
              width: double.infinity,
              height: 42,
              child: OutlinedButton.icon(
                onPressed: onFlashcards,
                icon: const Icon(Icons.spellcheck),
                label: const Text('Vocabulary Practice'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickTranslateDialog extends StatefulWidget {
  const _QuickTranslateDialog();

  @override
  State<_QuickTranslateDialog> createState() => _QuickTranslateDialogState();
}

class _QuickTranslateDialogState extends State<_QuickTranslateDialog> {
  final _input = TextEditingController();
  final _translation = TranslationService();

  String? _result;
  bool _loading = false;

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _translate() async {
    if (_input.text.trim().isEmpty) {
      setState(() {
        _result = 'Enter Hindi text to translate.';
      });
      return;
    }

    setState(() {
      _loading = true;
      _result = null;
    });

    try {
      final result = await _translation.translateHindiToMundari(
        _input.text,
      );

      if (!mounted) return;

      setState(() {
        _result = result ??
            'Translation not available in the current offline dataset.';
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _result = 'Could not load the offline translation dataset.';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Offline translation'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Hindi → Mundari',
              style: TextStyle(
                color: Color(0xFF64748B),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _input,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Hindi text',
                hintText: 'हिंदी में लिखें',
              ),
            ),
            if (_result != null) ...[
              const SizedBox(height: 16),
              const Text(
                'Mundari translation',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6),
              SelectableText(_result!),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Close'),
        ),
        FilledButton.icon(
          onPressed: _loading ? null : _translate,
          icon: _loading
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                  ),
                )
              : const Icon(Icons.translate),
          label: const Text('Translate'),
        ),
      ],
    );
  }
}

class _LessonPlannerDialog extends StatefulWidget {
  const _LessonPlannerDialog();

  @override
  State<_LessonPlannerDialog> createState() => _LessonPlannerDialogState();
}

class _LessonPlannerDialogState extends State<_LessonPlannerDialog> {
  final _title = TextEditingController();
  final _grade = TextEditingController();
  final _subject = TextEditingController();
  final _topic = TextEditingController();
  final _objective = TextEditingController();
  final _hindi = TextEditingController();

  final _translation = TranslationService();

  String? _mundari;
  bool _loading = false;

  @override
  void dispose() {
    _title.dispose();
    _grade.dispose();
    _subject.dispose();
    _topic.dispose();
    _objective.dispose();
    _hindi.dispose();
    super.dispose();
  }

  Future<void> _translate() async {
    if (_hindi.text.trim().isEmpty) {
      setState(() {
        _mundari = 'Enter Hindi lesson content to translate.';
      });
      return;
    }

    setState(() {
      _loading = true;
      _mundari = null;
    });

    try {
      final value = await _translation.translateHindiToMundari(
        _hindi.text,
      );

      if (mounted) {
        setState(() {
          _mundari = value ??
              'Translation not available in the current offline dataset.';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _mundari = 'Could not load the offline translation dataset.';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  Widget _field(
    String label,
    TextEditingController controller, {
    int lines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        minLines: lines,
        maxLines: lines,
        decoration: InputDecoration(
          labelText: label,
          alignLabelWithHint: lines > 1,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Create Lesson'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Hindi → Mundari',
                  style: TextStyle(
                    color: Color(0xFF64748B),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _field('Lesson title', _title),
              _field('Class / Grade', _grade),
              _field('Subject', _subject),
              _field('Topic', _topic),
              _field(
                'Learning objective',
                _objective,
                lines: 2,
              ),
              _field(
                'Hindi lesson content',
                _hindi,
                lines: 4,
              ),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton.icon(
                  onPressed: _loading ? null : _translate,
                  icon: _loading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.translate),
                  label: const Text(
                    'Translate to Mundari',
                  ),
                ),
              ),
              if (_mundari != null) ...[
                const SizedBox(height: 14),
                _contentResult(
                  'Hindi Content',
                  _hindi.text,
                ),
                const SizedBox(height: 8),
                _contentResult(
                  'Mundari Content',
                  _mundari!,
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Close'),
        ),
      ],
    );
  }

  Widget _contentResult(String title, String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          SelectableText(
            text.isEmpty ? '—' : text,
          ),
        ],
      ),
    );
  }
}
